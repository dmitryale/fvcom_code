function[xgrid,ygrid,zgrd]=migrid2(time,press,dat,dt,dp,xs,ys)
% function[xgrid,ygrid,zgrid]=migrid2(x,y,z,dx,dy,xs,ys)
% function to grid data: linear, weighted box averages
% x, y, and z must be column vectors
% dx and dy are dimensions of grid box, must have same
% dimensions as x and y (eg. time and pressure).
% xs and ys are the search 'radii' from the centre of each box
% xgrid is returned as a row vector, ygrid is returned 
% as a column vector. zgrid is the matrix of gridded data.
% Boxes containing no data points are returned as NaNs
% V1.0 MEI June 2000

time=time';
xgrid=[min(time):dt:max(time)];
ygrid=[min(press):dp:max(press)]';
C=length(xgrid); % no. columns
R=length(ygrid); % no. rows
K=R*C; % total no boxes

zgrd=NaN*ones(R,C);
k=1;
disp(datestr(now))
for c=1:C
  for r=1:R
    boxbl(k,1)=xgrid(c); % bottom left x
    boxbl(k,2)=ygrid(r); % bottom left y
    boxmidx=boxbl(k,1)+dt/2; % centre of box x
    boxmidy=boxbl(k,2)+dp/2; % centre of box y
%    ind=find(press > boxbl(k,2) & press < boxbl(k,2)+dp ...
%        & time' > boxbl(k,1) & time' < boxbl(k,1)+dt);
    ind=find(press > boxmidy-ys & press < boxmidy+ys ...
        & time' > boxmidx-xs & time' < boxmidx+xs);
     if isempty(ind) ~= 1
       clear xprime yprime rad theta
       xprime=time(ind)-boxmidx;
       yprime=press(ind)-boxmidy;
       xp=xprime/(dt/2); % scale coords between -1 and 1
       yp=yprime/(dp/2); %             "
       [theta,rad] = cart2pol(xp,yp');
       invrad=1./rad; % 1/dist for weightings 
       w=(invrad/norm(invrad,1)); % weights for average
       zgrd(r,c)=w*dat(ind);
     end
     k=k+1;
  end
end        
disp(datestr(now))
