%vmadcp_cd122_asill_ss.m

%PROCESS TRANSECT ADCP DATA
%OVERLAY PROCESSED SEASOAR DATA

%first level of transect processing

close all
clear all
filename='M:\mar_phys\cd122\vmadcp\cd122009t.mat'
load(filename)
for i=1:length(u)
   ind1=find(zbin>0.85*depth(i));
   u(i,ind1)=NaN;
   v(i,ind1)=NaN;
   w(i,ind1)=NaN;
   ei1(i,ind1)=NaN;
   
   %ind2=find(u(i,:)<-300 | u(i,:)>300);
   %u(i,ind2)=NaN;
   %v(i,ind2)=NaN;
   %w(i,ind2)=NaN;
   %ei1(i,ind2)=NaN;
   
end
ind2=find(pg<80);
u(ind2)=NaN;
v(ind2)=NaN;
w(ind2)=NaN;
%% rotate 
%for rn=1:360
theta=-60;
theta=3.1415927*theta/180;
rotate(1,1)=cos(theta);
rotate(2,1)=sin(theta);
rotate(1,2)=-sin(theta);
rotate(2,2)=cos(theta);
for i=1:length(zbin)
   vec=[u(:,i) v(:,i)];
   un=rotate*vec';
   ur(:,i)=un(1,:)';
   vr(:,i)=un(2,:)';
end
%err(rn)=std(un(finite(un(:,2)),2));
%end

subplot(2,1,1)
pcolor(mtime,-zbin,u')
colorbar
shading flat
datetick('x')
subplot(2,1,2)
pcolor(mtime,-zbin,v')
shading flat
colorbar
datetick('x')

start(1)=datenum(2000,5,14,11,35,0);
stop(1)=datenum(2000,5,14,14,0,0);
start(2)=datenum(2000,5,14,14,9,0);
stop(2)=datenum(2000,5,14,16,33,0);
start(3)=datenum(2000,5,14,16,41,0);
stop(3)=datenum(2000,5,14,19,6,0);
start(4)=datenum(2000,5,14,19,10,0);
stop(4)=datenum(2000,5,14,21,39,0);

s1=[-5.4250 55.3783];
s2=[-5.2667 55.2500];
s3=[-5.0667 55.2333];

%select parameter

par=input('Select the parameter to plot (s/t/d):  ','s');

for sec=1:4
   inda=find(mtime>start(sec) & mtime<stop(sec));
   
   %IMPORT SEASOAR DATA
   eval(['load M:\mar_phys\cd122\seasoar\asill' num2str(sec)])
   eval(['asill' num2str(sec) '_d  = (sw_dens(asill' num2str(sec) '_s,asill' num2str(sec) '_t,asill' num2str(sec) '_depth))-1000;'])
   eval(['ss_data  = asill' num2str(sec) '_' par ';'])
   eval(['ss_time  = asill' num2str(sec) '_time;'])
   eval(['ss_depth = asill' num2str(sec) '_depth;'])
   eval(['clear asill' num2str(sec) '_*'])
   
   %derive seasoar position data
   indss=find(mtime>=ss_time(1) & mtime<=ss_time(length(ss_time)));
   ss_lon=interp1(mtime(indss),lon(indss),ss_time);
   
   
   figure
   subplot(2,1,1)
   pcolor(lon(inda),-zbin,ur(inda,:)')
   shading flat
   shading interp
   caxis([-50 50])
   colorbar
   %datetick('x')
   title(['Along sill section ',num2str(sec),': X-sill current cms^{-1}'])
   set(gca,'ylim',[-45 0])
   set(gca,'xlim',[-5.5 -4.95])
   ylabel('depth (m)')
   hold on
   plot([s1(1) s1(1)],[-45 0],'k--')
   plot([s2(1) s2(1)],[-45 0],'k--')
   plot([s3(1) s3(1)],[-45 0],'k--')
   
   sz=size(ss_data);
   [cs,h]=contour(ss_lon,-ss_depth(3:sz(1)),ss_data(3:sz(1),:),'k');
   clabel(cs,h)
   
   if sec==1
      str1=datestr(start(sec));
      str2=datestr(stop(sec));
      text(-5.5,-5,str1)
      text(-5.15,-5,str2)
   elseif sec==2
      str1=datestr(start(sec));
      str2=datestr(stop(sec));
      text(-5.15,-5,str1)
      text(-5.5,-5,str2)
   elseif sec==3
      str1=datestr(start(sec));
      str2=datestr(stop(sec));
      text(-5.5,-5,str1)
      text(-5.15,-5,str2)
   elseif sec==4
      str1=datestr(start(sec));
      str2=datestr(stop(sec));
      text(-5.15,-5,str1)
      text(-5.5,-5,str2)
      
   end
   
   
   subplot(2,1,2)
   pcolor(lon(inda),-zbin,vr(inda,:)')
   shading flat
   shading interp
   caxis([-50 50])
   colorbar
   %datetick('x')
   title('Along sill current cms^{-1}')
   set(gca,'ylim',[-45 0])
   set(gca,'xlim',[-5.5 -4.95])
   ylabel('depth (m)')
   xlabel('longitude (degrees west)')
   hold on
   plot([s1(1) s1(1)],[-45 0],'k--')
   plot([s2(1) s2(1)],[-45 0],'k--')
   plot([s3(1) s3(1)],[-45 0],'k--')
   
   text(s1(1),-5,'S1')
   text(s2(1),-5,'S2')
   text(s3(1),-5,'S3')
   
   contour(ss_lon,-ss_depth(3:sz(1)),ss_data(3:sz(1),:),'k')
   
end
