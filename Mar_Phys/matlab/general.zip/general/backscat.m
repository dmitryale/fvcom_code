% script to input, read and calculate backscatter data from 300kHz ADCP
% Based on an Excel workbook written by Geraint Tarling
% Calculation follows the method described by Deines - RDI technical paper
% FRC July 2003

clear
close all

disp('This routine calculates absolute backscatter for the upwardlooking RDI 300kHz Sentinel')
pause(1.5)
disp(' ')
disp('It requires data obained using BBLIST RDI Software and exported from WinADCP')
pause(1.5)
disp(' ')
winadcp=input('Enter the full path and file name for WinADCP data: ','s');
eval(['load ',winadcp])
mtime=datenum(SerYear+2000,SerMon,SerDay,SerHour,SerMin,SerSec);
disp(' ')
%% Check for duplicate ensembles

step=(1:length(SerEnsembles))';
step_i=find(SerEnsembles==step);

mtime=mtime(step_i);
SerEAAcnt=SerEAAcnt(step_i,:);
start=input('deployment starts - yyyy,mm,dd,hh,mm,ss: ','s');
eval(['start=datenum(',start,');'])
deploy=find(mtime>=start);
pause(1.5)
disp(' ')
disp('Run BBLIST now to extract and export required variables and data')
pause(1.5)
disp(' ')
disp('Run BACKSCAT.FMT to extract series data.  Note the ASCII filename and path')
pause(1.5)
disp(' ')
bblist=input('Enter the full path and file name for BBLIST ASCII export: ','s');
eval(['load ',bblist])
pause(1.5)
disp(' ')
disp('Get ADCP parameters from menu ''Display -> ADCP Setup''')
pause(1.5)
disp(' ')

%% Obtain ADCP set-up values
B=input('Blank after transmit (m)    : ');
L=input('Transmit pulse length (m)   : ');
Ldbm=10*(log10(L));
D=input('Cell length (m)             : ');
theta=20; %Beam angle (degrees)
alpha=input('Absorption coeff (dB/m) : '); %Obtained from TRANSECT - use 0.07 for Kongsfjord
C=-143.5; % From Deines, Table 1
SSctd=input('Average speed of sound through column from CTD data (m/sec) : ');
disp(' ')
pause(1.5)
disp('Obtain ADCP series data')

% Echo intensity reference level
plot(SerEAAcnt(1:1000,1))
xlabel('Ensemble number')
ylabel('Counts')
Title('Average Pre-deployment Echo Intensity Reference Level for Bin #1')

EAens=input('Number of ensembles to calculate E_ref over all bins : ');
Er=SerEAAcnt(1:EAens,:);
Er=mean(Er(find(~isnan(Er))));
disp(' ')
disp(['Mean Echo Intensity Reference Level: ',num2str(Er)])
close
pause(2)

%Use data obtained through BBLIST

bblist_data=input('Enter BBLIST output filename (without .### extension) : ','s');

eval(['SS=',bblist_data,'(:,1);'])
SS=1./(SS/SSctd);

eval(['Tx=',bblist_data,'(:,2);'])
eval(['current=',bblist_data,'(:,3)*0.011451;'])
eval(['voltage=',bblist_data,'(:,4)*0.592157;'])
power=current.*voltage;
p_factor=power/power(deploy(1));
Pdbw=p_factor*14; % value of Pdbw=14.0 from Deines

figure(1)
subplot(3,1,1)
plot(Tx)
title('ADCP transducer temperature')
ylabel('Temp (^oC)')
subplot(3,1,2)
plot(SS)
title('ADCP calculated speed of sound')
ylabel('Speed of sound (m/sec)')
subplot(3,1,3)
plot(Pdbw)
title('Transducer power output')
ylabel('10Log(Power)')
xlabel('Ensemble Number')

%% Calculate slant range R
N=1:30; %bin number

for i=1:length(N)
    
    R(:,i)=((B+((L+D)/2)+((N(i)-1)*D)+(D/4))/(cos(deg2rad(theta))))*SS;
    
end

figure(2)
plot(R(deploy(1),:))
Title('Slant Range to Bin')
xlabel('Bin Number')
ylabel('Range (m)')

disp('Check that R for bin 1 is greater than 0.769')
disp('Press RETURN to continue')
pause

%% Calculate 2-alpha-R

alpha_n=(2*alpha*D)/(cos(deg2rad(theta)));
for i=1:length(N)
    sum_alpha_n(i)=alpha_n*i;
end

for i=1:length(N)
    two_alpha_r(i)=((2*alpha*B)/(cos(deg2rad(theta))))+sum_alpha_n(i);
end

%Calculate backscatter coefficient 'Sv'

Kc=0.5025;

for i=1:length(N)
    
    Sv(:,i)= C + ...
        (10*(log10((Tx+273.16).*(R(:,i).^2)))) - ...
        Ldbm - ...
    Pdbw + ...
    two_alpha_r(i) + ...
        Kc*(SerEAAcnt(:,i)-Er);
    
end




nweeks=ceil((mtime(end)-mtime(1))/7);

redblue=redbluecolmap(-200,200);
figure
wkstart=mtime(1);
for i=1:nweeks
    ind=find(mtime>=wkstart & mtime<=wkstart+7);
    wkstart=wkstart+7;
    subplot(nweeks,1,i)
    pcolor(mtime(ind),N,Sv(:,ind))
    datetick('x')
    shading flat
    %ylim([-210 0])
    colorbar
end