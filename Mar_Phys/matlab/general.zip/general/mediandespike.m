function [x,y] = mediandespike(mtime,sig,m);

%function [x,y] = mediandespike(mtime,sig,m);
%performs an m-point median despike on time series sig
% MEI Oct 2002
if length(sig) < m, return;end
n=fix(length(sig)/m)-1;
blocksig=reshape(sig(1:n*m),m,n); % block signal into sections of length m
blocktime=reshape(mtime(1:n*m),m,n); % block time into sections of length m
for i=1:n % loop through all blocks
    y(i)=median(blocksig(:,i));
    x(i)=mean(blocktime(:,i));
end


    



