function y = moveavg(x,n);

%Function y = moveavg(x.n)
%Smooths the vector with a moving (boxcar) average of size n

y = cumsum(x);

%  Add a zero at the beginning of the cumsum

[p,q] = size (x);
if			p==1, y = [0, y];
elseif 	q==1, y = [0; y];
else 		error ('First argument must be a vector');
end

%calcualte the moving average (running mean)
m=max(p,q)+1;
y = (y(n+1:m) - y(1:m-n))./n;




