function newmap=pox(min,max)
if min>0 | max<0
   disp('caxis range must be (-ve,+ve)')
   return
end
n=ones(64,3);

piv=round(64*abs(min/(min-max))); % find the index for the zero value
ipiv=64-piv;
% now make a poxy colormap
n(1:piv,1)=[0:(1/(piv-1)):1]';
n(piv:64,3)=[1:-(1/(ipiv)):0]';
n(:,2)=n(:,1);
n(piv:64,2)=[1:-(1/(ipiv)):0]';

newmap=n;
