% script to read transect narrowband ascii output files
% MEI Jan '02.
close all
clear
filein=input('type full input file path and name ','s');
nb=40; %input('number of bins in each ensemble ');
ne=1;
fid=fopen(filein,'r');
e1=1;
while 1
             for i=1:6
               line = fgetl(fid);
               if ~isstr(line), disp('file end found'),e1=999;, end
               if e1==1
               if i==1
                 disp(line) 
                 tstamp1=str2num(line(4));
                 tstamp2=str2num(line(8:9));
                 tstamp3=str2num(line(11:12));
                 tstamp4=str2num(line(14:15));
                 tstamp5=str2num(line(17:18));

                 mtime(ne)=datenum(2000,... 
                 tstamp1,tstamp2,tstamp3,tstamp4,tstamp5);
                 datestr(mtime);
               end
               if i==2
                   tmp=str2num(line);
                   depth(ne)=0.25*(tmp(5)+tmp(6)+tmp(7)+tmp(8));
               end
               if i==4
                 disp(line)
                 tmppos=str2num(line);
                 lat(ne)=tmppos(1);
                 lon(ne)=tmppos(2);
               end   
             end  
             end
             if e1==999, break, end
             for i=1:nb
               line=fgetl(fid);
               tmp=str2num(line);
               sz=size(tmp);
               u(ne,i)=tmp(4);  
               v(ne,i)=tmp(5);   
               w(ne,i)=tmp(6);
               e(ne,i)=tmp(7);
               zbin(i)=tmp(1);
               ei1(ne,i)=tmp(8);
               ei2(ne,i)=tmp(9);
               ei3(ne,i)=tmp(10);
               ei4(ne,i)=tmp(11);
               pg(ne,i)=tmp(12); % percent good

             end  
             ne=ne+1;
                

end
fclose(fid);
datestr(mtime)

