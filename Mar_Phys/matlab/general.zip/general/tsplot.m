function tsplot(t,s,p,refden)
%function tsplot(t,s,p,refden)
%function to draw TS-Diagram and plot the TS profile. Function must be
%passed column vectors of in situ temperature(t), salinity(s), 
%pressure in decibars(p), and a reference density in db(refden). 
%The CSIRO seawater routines must be in the Matlab path for this
%function to work
%MEI 11/2000

pt=sw_ptmp(s,t,p,refden);

mins=min(s);
maxs=max(s);
mint=min(pt);
maxt=max(pt);
sv=[mins:((maxs-mins)/100):maxs];
ptv=[mint:((maxt-mint)/100):maxt];

[X,Y]=meshgrid(sv,ptv);

pden=sw_dens(X,Y,refden);
[c,l]=contour(X,Y,pden-1000,'k');
%clabel(c,l,'manual');
clabel(c,l,'fontsize',12,'color','k');
hold on
plot(s,t,'ro')

xlabel('salinity PSU')
ylabel('potential temperature C')

