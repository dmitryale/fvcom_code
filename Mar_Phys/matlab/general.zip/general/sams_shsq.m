
function [s2,p_ave] = sams_shsq(u,v,z)
% function to work out shear squared from adcp u,v data
% usage [s2,p_ave] = sams_shsq(u,v,z)
%

%-------------
% CHECK INPUTS
%-------------
if ~(nargin==3) 
   error('sams_shsq.m: Must pass 3 parameters ')
end %if

% CHECK S,T,P dimensions and verify consistent
[ms,ns] = size(u);
[mt,nt] = size(v);
[mp,np] = size(z);

  
% CHECK THAT u & v HAVE SAME SHAPE
if (ms~=mt) | (ns~=nt)
   error('check_stop: u & v must have same dimensions')
end %if

% CHECK OPTIONAL SHAPES FOR P
if     mp==1  & np==1      % P is a scalar.  Fill to size of S
   z = z(1)*ones(ms,ns);
elseif np==ns & mp==1      % P is row vector with same cols as S
   z = z( ones(1,ms), : ); %   Copy down each column.
elseif mp==ms & np==1      % P is column vector
   z = z( :, ones(1,ns) ); %   Copy across each row
elseif mp==ms & np==ns     % PR is a matrix size(S)
   % shape ok 
else
   error('check_stop: z has wrong dimensions')
end %if
[mp,np] = size(z);
 

  
% IF ALL ROW VECTORS ARE PASSED THEN LET US PRESERVE SHAPE ON RETURN.
Transpose = 0;
if mp == 1  % row vector
   z       =  z(:);
   u       =  u(:);
   v       =  v(:);   

   Transpose = 1;
end %if
%***check_stop

   

%------
% BEGIN
%------
   Z = z;

[m,n] = size(z);
iup   = 1:m-1;
ilo   = 2:m;
p_ave = (z(iup,:)+z(ilo,:) )/2;
du = diff(u);
dv = diff(v);
dz    = diff(Z);
s2       = sqrt( ((du./dz).^2) + ((dv./dz).^2));

if Transpose
  s2    = s2';
  p_ave = p_ave';
end %if
return
%-------------------------------------------------------------------
