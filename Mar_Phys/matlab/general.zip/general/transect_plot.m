% first level of transect processing
close all
clear all
%cd \mar_phys\cd122\vmacdp
filename='\mar_phys\cd122\vmadcp\cd122009t.mat'
load(filename)
%cd \mar_phys\matlab\general
for i=1:length(u)
    ind1=find(zbin>0.85*depth(i));
    u(i,ind1)=NaN;
    v(i,ind1)=NaN;
    w(i,ind1)=NaN;
    ei1(i,ind1)=NaN;

    %ind2=find(u(i,:)<-300 | u(i,:)>300);
    %u(i,ind2)=NaN;
    %v(i,ind2)=NaN;
    %w(i,ind2)=NaN;
    %ei1(i,ind2)=NaN;

end
ind2=find(pg<80);
u(ind2)=NaN;
v(ind2)=NaN;
w(ind2)=NaN;
%% rotate 
%for rn=1:360
%  theta=-11;
%  theta=3.1415927*theta/180;
%  rotate(1,1)=cos(theta);
%  rotate(2,1)=sin(theta);
%  rotate(1,2)=-sin(theta);
%  rotate(2,2)=cos(theta);
%  for i=1:length(zbin)
%   vec=[u(:,i) v(:,i)];
%   un=rotate*vec';
%   u11(:,i)=un(1,:)';
%   v11(:,i)=un(2,:)';
%  end
  %err(rn)=std(un(finite(un(:,2)),2));
%end

subplot(2,1,1)
pcolor(mtime,-zbin,u')
colorbar
shading flat
datetick('x')
subplot(2,1,2)
pcolor(mtime,-zbin,v')
shading flat
colorbar
datetick('x')

inda=[1:100];
figure
subplot(3,1,1)
pcolor(mtime(inda),-zbin,u(inda,:)')
shading flat
shading interp
colorbar
datetick('x')
title('cms^{-1}')
set(gca,'ylim',[-110 0])
subplot(3,1,2)
pcolor(mtime(inda),-zbin,w(inda,:)')
shading flat
shading interp
colorbar
datetick('x')
title('vertical cms^{-1}')
set(gca,'ylim',[-110 0])
subplot(3,1,3)
pcolor(mtime(inda),-zbin,ei1(inda,:)')
shading flat
shading interp
caxis([60 90])
colorbar
datetick('x')
title('backscatter')
set(gca,'ylim',[-110 0])

