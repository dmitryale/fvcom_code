function y = movestd(x,n);

%Function y = movestd(x,n)
%Calculates the moving standard deviation of a vector over period size n

%FRC  April 2002

x_sq = x.*x;

sum_x_sq = cumsum(x_sq);

sum_x = cumsum(x);

%add a zero at the beginning of each vector

[p,q] = size (x);

if p==1
   
   x_sq = [0, x_sq];
   sum_x_sq = [0, sum_x_sq];
   sum_x = [0, sum_x];
   
elseif q==1
   
   x_sq = [0; x_sq];
   sum_x_sq = [0; sum_x_sq];
   sum_x = [0; sum_x];
   
else error ('First argument must be a vector')
   
end

%Calculate the terms in STD equation

m=max(p,q)+1;

term1 = n*(sum_x_sq(n+1:m) - sum_x_sq(1:m-n));

term2 = (sum_x(n+1:m) - sum_x(1:m-n)).^2;

numer = term1 - term2;
denom = n*(n-1);

y = sqrt(numer/denom);

