% script to plot CTD section from Scotia 15
%load 
%clear
close all

T=data_tal;
S=data_sal;

dx=5;
dz=5;
xs=10;
zs=2.5;
[xgrid,ygrid,zgrid]=migrid2(T(:,1),T(:,2),T(:,3),dx,dz,xs,zs);
level=[-1 0 1 2:0.5:12]
[c,l]=contourf(xgrid,-ygrid,zgrid,level);
clabel(c,l,'manual');
colorbar
figure
surf(xgrid,-ygrid,zgrid);
shading interp


