function shear=despike(sh,thd,iplt)
% function shear=despike(sh,thd,iplt)
% Despike a shear time series based on the amount
% of shear variance contained by 2% of each data segment.
% Suggest you try a threshold between thd = 0.3 to 0.5
% if iplt is passed, then plot before and after shear
% RKD 4/97
shear=sh;  % initialize despiked array
if length(sh) < 500, return; end
M=500;
N=fix(length(sh)/M)-1;
block=reshape(sh(1:M*N),M,N);  % block the data into sections of length M
ss=10;sr=ss*2;
nsp=0;
for i=2:N,    % loop through all the blocks
   indx1=i*M-(M-1);
   varb=std(block(:,i))^2;
   if varb > 0.1,  % don't bother if the data is just noise
   spikes=reshape(block(:,i),ss,M/ss);
   vars=std(spikes).^2;
   indx=find(vars > (thd*varb*M/ss));
   if ~isempty(indx),  % a spike exists in this section
      med=median(block(:,1));
      for is=1:length(indx)
         nsp=nsp+1;
         indxm=indx(is)*ss-(ss/2);
         indxb=indx1+[indxm-sr/2:indxm+sr/2];
         shear(indxb)=med*ones(size(shear(indxb)));
      end
   end
   end
end
disp([num2str(nsp) ' shear spikes removed']);
if nargin == 3,
   clf;plot(sh,(length(sh):-1:1),'b',shear,(length(sh):-1:1),'r');
end
% fini
