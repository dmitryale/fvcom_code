% script to input, read and calculate backscatter data from 300kHz ADCP
% Based on an Excel workbook written by Geraint Tarling
% Calculation follows the method described by Deines - RDI technical paper
% FRC July 2003

clear
close all

disp('This routine calculates absolute backscatter for the upwardlooking RDI 300kHz Sentinel')
disp(' ')
disp('It reads in the raw binary data using RDI2MATLAB routines - which can take some time!')
disp(' ')
disp('If there is more than 1 file for the deployment they are loaded separately and concatenated.')
pause(2)
disp(' ')
nfiles=input('Number of binary files for this deployment (files should have the sequential .000 .001 etc. extension: ');
path=input('What is the directory path for the binary files :','s');
filename=input('What is the common file name :','s');

%% initialise variables

mtime=[];
SS=[];
current=[];
voltage=[];
Tx=[];
E=[];

for n=1:nfiles 
    
    eval(['adcp=rdradcp1(''',path,'\',filename,'.00',num2str(n-1),''');'])
    
    if n==1
        %% Obtain ADCP set-up values
        B=adcp.config.blank;
        L=adcp.config.xmit_pulse;
        Ldbm=10*(log10(L));
        D=adcp.config.cell_size;
        theta=adcp.config.beam_angle;
    else
    end
    
    mtime=[mtime adcp.mtime];
    SS=[SS adcp.ssp];
    current=[current adcp.adc(1,:)];
    voltage=[voltage adcp.adc(2,:)];
    Tx=[Tx adcp.temperature];
    E=[E adcp.intens];
    
end

%Obtain additional deployment information
start=input('deployment starts - yyyy,mm,dd,hh,mm,ss: ','s');
eval(['start=datenum(',start,');'])
stop=input('deployment ends - yyyy,mm,dd,hh,mm,ss: ','s');
eval(['stop=datenum(',stop,');'])
deploy=find(mtime>=start & mtime<=stop);

alpha=input('Absorption coeff (dB/m) : '); %Obtained from TRANSECT - use 0.07 for Kongsfjord
SSctd=input('Average speed of sound through water column from CTD data (m/sec) : ');

Kc=0.5025; % From RDI
C=-143.5; % From Deines, Table 1
current=current*0.011451;
voltage=voltage*0.592157;
power=current.*voltage;
p_factor=power/power(deploy(1));
Pdbw=p_factor*14; % value of Pdbw=14.0 from Deines

%Obtain beam averages for E
E=squeeze(mean(E,2));

% Echo intensity reference level
figure(1)
clf
plot(E(1:1000,1))
xlabel('Ensemble number')
ylabel('Counts')
Title('Echo Intensity for Bin #1')

Eens=input('Number of ensembles to calculate E_ref over all bins : ');
Er=E(1:Eens,:);
Er=mean(Er(find(~isnan(Er))));
disp(' ')
disp(['Mean Echo Intensity Reference Level: ',num2str(Er)])
close
pause(2)


figure(2)
subplot(3,1,1)
plot(Tx)
title('ADCP transducer temperature')
ylabel('Temp (^oC)')
subplot(3,1,2)
plot(SS)
title('ADCP calculated speed of sound')
ylabel('Speed of sound (m/sec)')
subplot(3,1,3)
plot(Pdbw)
title('Transducer power output')
ylabel('10Log(Power)')
xlabel('Ensemble Number')

%% Calculate slant range R
N=adcp.config.n_cells; %number of bins

for i=1:length(N)
    
    R(:,i)=((B+((L+D)/2)+((N(i)-1)*D)+(D/4))/(cos(deg2rad(theta))))*SS;
    
end

figure(3)
plot(R(deploy(1),:))
Title('Slant Range to Bin')
xlabel('Bin Number')
ylabel('Range (m)')

disp('Check that R for bin 1 is greater than 0.769')
disp('Press RETURN to continue')
pause

%% Calculate 2-alpha-R

alpha_n=(2*alpha*D)/(cos(deg2rad(theta)));
for i=1:length(N)
    sum_alpha_n(i)=alpha_n*i;
end

for i=1:length(N)
    two_alpha_r(i)=((2*alpha*B)/(cos(deg2rad(theta))))+sum_alpha_n(i);
end

%Calculate backscatter coefficient 'Sv'

for i=1:length(N)
    
    Sv(:,i)= C + ...
        (10*(log10((Tx+273.16).*(R(:,i).^2)))) - ...
        Ldbm - ...
    Pdbw + ...
    two_alpha_r(i) + ...
        Kc*(SerEAAcnt(:,i)-Er);
    
end




%nweeks=ceil((mtime(end)-mtime(1))/7);

%redblue=redbluecolmap(-200,200);
%figure
%wkstart=mtime(1);
%for i=1:nweeks
%    ind=find(mtime>=wkstart & mtime<=wkstart+7);
%    wkstart=wkstart+7;
%    subplot(nweeks,1,i)
%    pcolor(mtime(ind),N,Sv(:,ind))
%    datetick('x')
%    shading flat
%    %ylim([-210 0])
%    colorbar
%end