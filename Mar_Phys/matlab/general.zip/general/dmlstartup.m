%STARTUPSAV   Startup file
%   Change the name of this file to STARTUP.M. The file 
%   is executed when MATLAB starts up, if it exists 
%   anywhere on the path.  In this example, the
%   MAT-file generated during quitting using FINISHSAV
%   is loaded into MATLAB during startup.

%   Copyright (c) 1984-98 by The MathWorks, Inc.
%   $Revision: 1.1 $  $Date: 1998/05/15 20:51:02 $

addpath M:\Mar_phys\matlab\mla_adcp\loaddata1
addpath M:\Mar_phys\matlab\mla_adcp\loaddata2
addpath M:\Mar_phys\matlab\mla_adcp\plotting
addpath M:\Mar_phys\matlab\mla_adcp\processing
addpath M:\Mar_phys\matlab\mla_adcp\qcdata
addpath M:\Mar_phys\matlab\mla_adcp\writedata
addpath M:\Mar_phys\matlab\mla_adcp\timeplt
addpath M:\Mar_phys\matlab\mla_adcp\functions
addpath M:\Mar_phys\matlab\mla_adcp\adcptide
addpath M:\Mar_phys\matlab\mooring
addpath M:\Mar_phys\matlab\t_tide
addpath M:\Mar_phys\matlab\m_map
addpath M:\Mar_phys\matlab\seawater
addpath M:\Mar_phys\matlab\spider
addpath M:\Mar_phys\matlab\general\maps

%addpath M:\Mar_phys\matlab
%addpath M:\Mar_phys\matlab

% set a few things
format long g