% script to read in mini logger data 
% MEI Feb 2003 
% FRC March 2003 - Made small modifications to the display of minilog parameters
% FRC March 2003 - Add timing correction routine
% FRC March 2003 - Add data extraction routine
% FRC MArch 2003 - Add linear calibration correction
% FRC Oct 2003 - Two different date representations DD-MM-YY or YYYY-MM-DD

clear
close all
fnm=input('full file name> ','s');
fid=fopen(fnm,'r');
line1=fgetl(fid);
line2=fgetl(fid);
line3=fgetl(fid);
line4=fgetl(fid);
line5=fgetl(fid);
line6=fgetl(fid);
line7=fgetl(fid);
line8=fgetl(fid);

if line1(12:13) == '12' % check for high res logger
    disp('12 bit')
else
    disp('8 bit')
end
if line1(length(line1)) == 'D' % check for minilog with pressure
    td=1;
    disp('minilog TD')
else
    td=0;
end

if line8(9)==','|line8(9)==' ' % will accept either 2002 or 02 to represent year
    yr=2;
    if line8(9)==','
        disp('comma delimited')
        dl=',';
    end
    if line8(9)==' '
        disp('white-space delimited')
        dl='none';
    end
else
    yr=4;
    if line8(11)==','
        disp('comma delimited')
        dl=',';
    end
    if line8(11)==' '
        disp('white-space delimited')
        dl='none';
    end
end

serialno=line2(17:20);
disp(['serial number = ',num2str(serialno)])
study=line3(3:length(line3));
disp(['study name = ',num2str(study)])
period=line6(3:length(line6));
disp(['Sample Interval (hh:mm:ss) = ',num2str(period)])
fclose(fid);

if td ==0
    [dte,tim,t,dum1] = textread(fnm,'%s %s %f %u','headerlines',7,'delimiter',dl);
else
    [dte,tim,t,dum1,p,dum2] = textread(fnm,'%s %s %f %u %f %u','headerlines',7,'delimiter',dl);
end

dte1=char(dte);
dte2=char(tim);
for i=1:length(dte)
    if yr==2
        yyyy=2000+str2num(dte1(i,1:2));
        mmm=str2num(dte1(i,4:5));
        dd=str2num(dte1(i,7:8));
    else
        yyyy=str2num(dte1(i,7:10));
        mmm=str2num(dte1(i,4:5));
        dd=str2num(dte1(i,1:2));
    end
    hh=str2num(dte2(i,1:2));
    mm=str2num(dte2(i,4:5));
    ss=str2num(dte2(i,7:8));
    mtime(i)=datenum(yyyy,mmm,dd,hh,mm,ss);
end

figure(1)
plot(mtime,t)
datetick('x','mm/dd/yy')
xlabel('Date (MONTH/DATE/YEAR)')
ylabel('Temperature (^oC)')
title('ALL DATA')

if td==1
    figure(2)
    plot(mtime,p)
    datetick('x','mm/dd/yy')
    xlabel('Date (MONTH/DATE/YEAR)')
    ylabel('Depth (m)')
    title('ALL DATA')
end


%% APPLY LINEAR CALIBRATION

disp(' ')
cal=input('Do you wish to apply a calibration correction of the form y = Ax + B ? ','s');
if cal == 'y'
    disp(' ')
    A=input('Enter the value of (A) : ');
    B=input('Enter the value of (B) : ');
    t=(t*A)+B;
end

%% APPLY TIMING CORRECTIONS

disp(' ')
disp(['Record starts :  ',datestr(mtime(1))])
disp(['Record ends   :  ',datestr(mtime(end))])
disp(' ')

corr=input('Do you wish to apply a timimng correction to the data (y/n) ? ','s');
if corr == 'y'
    disp(' ')
    tcorr=input('Enter the magnitude of the correction - yyyy,mm,dd,hh,mm,ss: ','s');
    addsub=input('Should this correction be ADDED to the time coordinate (y/n) ? ','s');
    if addsub == 'y'
        mtime=mtime + eval(['datenum(',tcorr,')']);
    else
        mtime=mtime - eval(['datenum(',tcorr,')']);
    end
end

disp(' ')
disp(['Record starts (corrected) :  ',datestr(mtime(1))])
disp(['Record ends (corrected)  :  ',datestr(mtime(end))])
disp(' ')


%% EXTRACT A SUB_SET OF THE DATA

subset=input('Do you wish to extract a subset of the data (y/n) ? ','s');
if subset == 'y'
    start   = input('Data segment starts - yyyy,mm,dd,hh,mm,ss: ','s');
    stop    = input('Data segment stops - yyyy,mm,dd,hh,mm,ss: ','s');
    eval(['start=datenum(',start,');'])
    eval(['stop=datenum(',stop,');'])
    
    if  datenum(start)<datenum(mtime(1))| datenum(stop)>datenum(mtime(end))
        display('ERROR! - Data segment exceeds deployment period')
        start   = input('Data segment starts - yyyy,mm,dd,hh,mm,ss: ','s');
        stop    = input('Data segment stops - yyyy,mm,dd,hh,mm,ss: ','s');
        eval(['start=datenum(',start,');'])
        eval(['stop=datenum(',stop,');'])
    end
    
    if td == 1
        t=t(find(mtime>start & mtime<stop));
        p=p(find(mtime>start & mtime<stop));
        mtime=mtime(find(mtime>start & mtime<stop));
        
    else
        t=t(find(mtime>start & mtime<stop));
        mtime=mtime(find(mtime>start & mtime<stop)); 
        
    end
    
    figure(1)
    plot(mtime,t,'r')
    datetick('x','mm/dd/yy')
    xlabel('Date (MONTH/DATE/YEAR)')
    ylabel('Temperature (^oC)')
    title('EXTRACTED DATA')

    if td==1
        figure(2)
        plot(mtime,p,'r')  
        datetick('x','mm/dd/yy')
        xlabel('Date (MONTH/DATE/YEAR)')
        ylabel('Depth (m)')
        title('EXTRACTED DATA')
    end
    
end

disp(' ')
sav=input('Save extracted data as a MAT file y/n ?  ','s');
if sav == 'y'
    if td==0
        eval(['save ',fnm(1:(length(fnm)-4)),' mtime t'])  
    else
        eval(['save ',fnm(1:(length(fnm)-4)),' mtime t p'])  
    end
    
end

close all
clear all

