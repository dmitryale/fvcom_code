function[AREA1 ] = area_sp(SIDEA,SIDEB,SIDEC)
% call from  cells_area ; mod_spherical.F 
% (c) dmitry.aleynik@sams.ac.uk 2018.09.13;                               & 
%  __o_O__�                                                               &
%  \_____/ ~~~~~~<@})))< ~ ~ ~~~~~ ~~~ SAMS KTP                           &
%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
%   SUBROUTINE AREA_DBL(SIDEA,SIDEB,SIDEC,AREA1)
 DEG2RAD=pi/180;  %   DEG2RAD=3.14159265/180;
 REARTH= 6371.0*1000; %m
   
    SIDE1=SIDEA/REARTH;
    SIDE2=SIDEB/REARTH;
    SIDE3=SIDEC/REARTH;
  
    PSUM=0.5*(SIDE1+SIDE2+SIDE3);
    PM=sin(PSUM)*sin(PSUM-SIDE1)*sin(PSUM-SIDE2)*sin(PSUM-SIDE3);
    PM=sqrt(PM)/(2.0*cos(SIDE1*0.5)*cos(SIDE2*0.5)*cos(SIDE3*0.5));
    QMJC = 2.0*asin(PM);

    AREA1=REARTH*REARTH*QMJC;
    
%    return
end % SUBROUTINE AREA_DBL
