function [Mesh] = cells_area(Mesh, nmfcell,I_MFCELL_N)
% COMPUTE CONTROL VOLUMEs ART1,2: FOR FLUXES OF NODAL BASED VALUES,24 sec &
%\FVCOM_code\cell_area.F, mod_meanflow.F, tge.F, mode_input.F:L3549       &
% Mesh.tri = Mesh.tri_grd(:,[1,3,2]); % reorderd elements in clockwise order as in FVCOM native nv
% (c) dmitry.aleynik@sams.ac.uk 2018.10.09  - 2011.10.10                  &
%  __o_O__�                                                               &
%  \_____/ ~~~~~~<@})))< ~ ~ ~~~~~ ~~~ SAMS                               &
%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    SPHERICAL = true;
 if max(abs(Mesh.x(:,2))) > 90,  SPHERICAL = false; end
   DEG2RAD = pi/180;   REARTH= 6371.0*1000; %m
   TPI       = DEG2RAD*REARTH ; %!TPI=pi*rearth/180.=3.14159265/180.0*6371.*1000.

  NV = Mesh.tri ;  
  N  = Mesh.Nelems;
  M  = Mesh.Nverts;
 NBE   = Mesh.nbe;
 NTVE  = Mesh.ntve;
 NBVE  = Mesh.nbve;
 NBVT  = Mesh.nbvt;
 ISONB = Mesh.isonb;
  
    H = Mesh.x(:,3);            % =D  
   VX = Mesh.x(:,1);
   VY = Mesh.x(:,2);   
%% from    setup_metrics ==>
geog=Mesh.geog;
   Nelems=N;
   Nverts=M;
  ART=zeros(N,1);   
 
 if  (SPHERICAL),...
   for I=1:N,... 
     VX1=VX(NV(I,1));
     VX2=VX(NV(I,2));
     VX3=VX(NV(I,3));
     VY1=VY(NV(I,1));
     VY2=VY(NV(I,2));
     VY3=VY(NV(I,3));
    [side1] = arc(VX2,VY2,VX3,VY3);
    [side2] = arc(VX3,VY3,VX1,VY1);
    [side3] = arc(VX1,VY1,VX2,VY2);
    [area1] = area_sp(side1,side2,side3);
     ART(I,1)=area1;    
 
   end   
 else 
  for I=1:N,...
  ART(I,1)=(VX(NV(I,2)) - VX(NV(I,1))) * (VY(NV(I,3)) - VY(NV(I,1))) - ...
           (VX(NV(I,3)) - VX(NV(I,1))) * (VY(NV(I,2)) - VY(NV(I,1)));
  end
  ART    = abs(0.5.*ART);   
 end % spherical
%% ===============
 Mesh.art  = ART;
%%

%  !-------COMPUTE CONTROL VOLUME ART1: CV FOR FLUXES OF NODAL BASED VALUES-------!
%% ======== ======= ART1 ART2? 
   ART1=zeros(M,1);
   ART2=zeros(M,1);
      MAX_NBRE = max(NTVE)+1;
   XX=zeros(2*MAX_NBRE+1) ;
   YY=zeros(2*MAX_NBRE+1) ;
    XC=zeros(N,1);  YC=zeros(N,1); 
      for I = 1:N,...
      XC(I) = (VX(NV(I,1))+VX(NV(I,2))+VX(NV(I,3)))/3;
      YC(I) = (VY(NV(I,1))+VY(NV(I,2))+VY(NV(I,3)))/3;
      end
%%  plot(Mesh.bndryx,Mesh.bndryy,'.');
   
for I=1:M,...
  if(ISONB(I) == 0) ,...
     for J=1:NTVE(I),...
         II=NBVE(I,J);
         J1=NBVT(I,J);
         J2=J1+1-fix((J1+1)/4)*3;     
      if (SPHERICAL),...
         xx1=VX(NV(II,J1));
         yy1=VY(NV(II,J1));
         xx2=VX(NV(II,J2));
         yy2=VY(NV(II,J2));
%              CALL ARCC(xx1,yy1,xx2,yy2,XXC,YYC) 
        [XXC,YYC ]= arcc(xx1,yy1,xx2,yy2 );
         XX(2*J-1)=XXC;
         YY(2*J-1)=YYC;        
         XX(2*J)=XC(II);
         YY(2*J)=YC(II);            
     else   
         XX(2*J-1)=(VX(NV(II,J1))+VX(NV(II,J2)))*0.5-VX(I);
         YY(2*J-1)=(VY(NV(II,J1))+VY(NV(II,J2)))*0.5-VY(I);
         XX(2*J)=XC(II)-VX(I);
         YY(2*J)=YC(II)-VY(I);
     end
    end
       
       XX(2*NTVE(I)+1)=XX(1);
       YY(2*NTVE(I)+1)=YY(1);

       for J=1:2*NTVE(I),...
        if  (SPHERICAL),...
          X1_DP=XX(J);
          Y1_DP=YY(J);
          X2_DP=XX(J+1);
          Y2_DP=YY(J+1);
          X3_DP=VX(I);
          Y3_DP=VY(I);            
    [side1] = arc(X1_DP,Y1_DP,X2_DP,Y2_DP);
    [side2] = arc(X2_DP,Y2_DP,X3_DP,Y3_DP);
    [side3] = arc(X3_DP,Y3_DP,X1_DP,Y1_DP);
    [area1] = area_sp(side1,side2,side3);       
          ART1(I)=ART1(I)+area1   ;         
        else        
          ART1(I)=ART1(I)+0.5*(XX(J+1)*YY(J)-XX(J)*YY(J+1));
        end
       end      
       ART1(I)=abs(ART1(I));
       
    else % not on a boundary
    
       for J=1:NTVE(I),...
         II=NBVE(I,J);
         J1=NBVT(I,J);
         J2=J1 + 1 - fix((J1+1)/4)*3 ;
        if  (SPHERICAL), ...
         xx1=VX(NV(II,J1));
         yy1=VY(NV(II,J1));
         xx2=VX(NV(II,J2));
         yy2=VY(NV(II,J2));
%               CALL ARCC(xx1,yy1,xx2,yy2,XXC,YYC) 
         [XXC,YYC ]= arcc(xx1,yy1,xx2,yy2);         
         XX(2*J-1)=XXC;
         YY(2*J-1)=YYC; 
         XX(2*J)=XC(II);
         YY(2*J)=YC(II); 
        else        
         XX(2*J-1)=(VX(NV(II,J1))+VX(NV(II,J2)))*0.5-VX(I);
         YY(2*J-1)=(VY(NV(II,J1))+VY(NV(II,J2)))*0.5-VY(I);
         XX(2*J)=XC(II)-VX(I);
         YY(2*J)=YC(II)-VY(I);
        end
       end
       
       J=NTVE(I)+1;
       II=NBVE(I,J-1);
       J1=NBVT(I,NTVE(I));
       J2=J1+2-fix((J1+2)/4)*3;
     if (SPHERICAL)
       xx1 =  VX(NV(II,J1));
       yy1 =  VY(NV(II,J1));
       xx2 =  VX(NV(II,J2));
       yy2 =  VY(NV(II,J2));
%                CALL ARCC(xx1,yy1,xx2,yy2,XXC,YYC) 
          [XXC,YYC ]= arcc(xx1,yy1,xx2,yy2);        
    
       XX(2*J-1)=XXC;
       YY(2*J-1)=YYC ;
          
       XX(2*J)=VX(I);
       YY(2*J)=VY(I);          

       XX(2*J+1)=XX(1);
       YY(2*J+1)=YY(1);

     else
       XX(2*J-1)=(VX(NV(II,J1))+VX(NV(II,J2)))*0.5-VX(I);
       YY(2*J-1)=(VY(NV(II,J1))+VY(NV(II,J2)))*0.5-VY(I);

       XX(2*J)=VX(I)-VX(I);
       YY(2*J)=VY(I)-VY(I);

       XX(2*J+1)=XX(1);
       YY(2*J+1)=YY(1);
     end
       
     for J=1:2*NTVE(I)+2,...
      if   (SPHERICAL),...
        X1_DP= XX(J);
        Y1_DP= YY(J);
        X2_DP= XX(J+1);
        Y2_DP= YY(J+1);
        X3_DP= VX(I);
        Y3_DP= VY(I);
        [side1] = arc(X1_DP, Y1_DP, X2_DP, Y2_DP);
        [side2] = arc(X2_DP, Y2_DP, X3_DP, Y3_DP);
        [side3] = arc(X3_DP, Y3_DP, X1_DP, Y1_DP);
        [area1] = area_sp(side1,side2,side3);   
        
        ART1(I)=ART1(I)+area1 ;            
      else            
        ART1(I)=ART1(I)+0.5*(XX(J+1)*YY(J)-XX(J)*YY(J+1));
      end
      end
       ART1(I)=abs(ART1(I));
  end  %isonb  ==0  
end %72 I
%% ----------------
  for I=1:M,...
     ART2(I) = sum(ART(NBVE(I,1:NTVE(I))));
  end
 Mesh.art1 =ART1;
 Mesh.art2 =ART2;
 Mesh.xc = XC;
 Mesh.yc = YC;  

%% ----------------------sides: 
ISET=zeros(N,3);  TEMP=zeros((N)*3,2); TEMP2=zeros((N)*3,2);
          NE=0;
  for I=1:N,...
     for J=1:3,...
       if (ISET(I,J) == 0),...
         NE   = NE + 1;
         INEY = NBE(I,J);
         ISET(I,J) = 1;
         
         for JN=1:3,...
                 if INEY > 0 ...                                %!da ???
           if (I == NBE(INEY,JN)) , ISET(INEY,JN) = 1; end
                 end
         end
         
         TEMP(NE,1) = I ; TEMP(NE,2) = INEY;
         TEMP2(NE,1) = NV(I,J+1-fix((J+1)/4)*3);
         TEMP2(NE,2) = NV(I,J+2-fix((J+2)/4)*3);
       end
     end
  end
% ================================
   IEC(:,1) = TEMP(1:NE,1);
   IEC(:,2) = TEMP(1:NE,2);
   IENODE(:,1) = TEMP2(1:NE,1);
   IENODE(:,2) = TEMP2(1:NE,2);
   
  Mesh.ne     =NE;     % number of unique element edges  
  Mesh.ienode =IENODE; % the identification number of two end points of an edge  
  Mesh.iec    =IEC;    % counting number identifying two connected cells 
                     clear TEMP TEMP2
                     
 DLTXC=zeros(NE,1);  DLTYC=zeros(NE,1);  XIJC =zeros(NE,1); 
 YIJC =zeros(NE,1); DLTXYC=zeros(NE,1);  SITAC =zeros(NE,1); 

if  (SPHERICAL),...
  for I=1:NE
     X1_DP=VX(IENODE(I,1));
     Y1_DP=VY(IENODE(I,1));
     X2_DP=VX(IENODE(I,2));
     Y2_DP=VY(IENODE(I,2));     
            
    [XXC,YYC ]= arcc(X2_DP,Y2_DP,X1_DP,Y1_DP);   
    [side]    = arcx(X1_DP,Y1_DP,X2_DP,Y2_DP);

     XTMP  = VX(IENODE(I,2))*TPI-VX(IENODE(I,1))*TPI;
     XTMP1 = VX(IENODE(I,2))-VX(IENODE(I,1));
     if (XTMP1 > 180.0 ), ...
       XTMP = -360.0 *TPI+XTMP;
     elseif (XTMP1 < -180.0 ), ...
       XTMP = 360.0 *TPI+XTMP;
     end
  
     DLTXC(I) =XTMP*cos(DEG2RAD*(VY(IENODE(I,2))+VY(IENODE(I,1)))*0.5 );
     DLTYC(I) =(VY(IENODE(I,2))-VY(IENODE(I,1)))*TPI;
          
     [side] = arc(X1_DP, Y1_DP, X2_DP, Y2_DP);
 
     DLTXYC(I) = side;
     SITAC(I) =atan2(DLTYC(I),DLTXC(I));
     XIJC(I)=XXC;
     YIJC(I)=YYC;
   end
else
 for I=1:NE,...
     DLTXC(I) =  VX(IENODE(I,2))-VX(IENODE(I,1));
     DLTYC(I) =  VY(IENODE(I,2))-VY(IENODE(I,1));
     XIJC(I)  = (VX(IENODE(I,1))+VX(IENODE(I,2)))/2.0;
     YIJC(I)  = (VY(IENODE(I,1))+VY(IENODE(I,2)))/2.0;
     DLTXYC(I)= sqrt(DLTXC(I)^2+DLTYC(I)^2);
     SITAC(I) = atan2(DLTYC(I),DLTXC(I));
 end
end

  Mesh.XIJC  =XIJC ;% the x-coordinate location of the middle points
  Mesh.YIJC  =YIJC ; 
  Mesh.DLTXC =DLTXC;% vx(ienode(i,2))-vx(idnode(i,1)) 
  Mesh.DLTYC =DLTYC;% vy(ienode(i,2))-vy(idnode(i,1)) 
  Mesh.DLTXYC=DLTXYC;% length of the edge 
  Mesh.SITAC =SITAC ;%  arctg(dltyc,dltxc) 

%% =======================
   RDISMF=zeros(nmfcell,2);
   ANGLEMF=zeros(nmfcell,1);
   MFAREA=zeros(nmfcell,1);
   NODE_MFCELL=zeros(nmfcell,2);
try    
 for I=1:nmfcell,...
       II=I_MFCELL_N(I);       
         ITMP=0;
       for J=1:3,...
         if (NBE(II,J) == 0 && ISONB(NV(II,J)) ~= 2) ,...
           JTMP=J;
           ITMP=ITMP+1;
         end
       end
       
       if(ITMP ~= 1),...
        disp(' NO OPEN BOUNDARY OR MORE THAN ONE OPEN BOUNDARY, L444');
        disp([' IN NO. ',num2str(I),' MEAN FLOW CELL''; ' num2str(II)]);
          %exit ; %   CALL PSTOP
%           stop
       end
%       
       J1=JTMP+1-fix( (JTMP+1)/4)*3; % int
       J2=JTMP+2-fix( (JTMP+2)/4)*3;
       
       I1=NV(II,J1);
       I2=NV(II,J2);
         
       NODE_MFCELL(I,1)=I1;
       NODE_MFCELL(I,2)=I2;

       HTMP=0.5*(H(I1)+H(I2)) ;   % ! may be a problem here, should be replaced dy D
       
       DY12=VY(I1)-VY(I2)  ;   
       DX12=VX(I1)-VX(I2);
       
       ATMP1=atan2(DY12,DX12);
       MFAREA(I,1)=sqrt( DX12^2 + DY12^2 )*HTMP  ;  %! for spherical coordinates is Phthagolean Theorem still valid?
       ANGLEMF(I,1)=ATMP1 + 3.1415927/2.0;         % pi/2;% 
       RDISMF(I,1)=ART1(I1)/(ART1(I1)+ART1(I2));
       RDISMF(I,2)=ART1(I2)/(ART1(I1)+ART1(I2));
 end
     Mesh.RDISMF =RDISMF;
     Mesh.ANGLEMF=ANGLEMF;
     Mesh.MFAREA =MFAREA;
     
end   
 