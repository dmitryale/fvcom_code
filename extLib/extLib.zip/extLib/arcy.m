function[ARCY1 ]= arcy(XX1,YY1,XX2,YY2)
% call from SHAPE_COEF_GCN
% (c) dmitry.aleynik@sams.ac.uk 2018.09.13;                               & 
%  __o_O__�                                                               &
%  \_____/ ~~~~~~<@})))< ~ ~ ~~~~~ ~~~ SAMS KTP                           &
%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
% SUBROUTINE ARCY_DBL(XX1,YY1,XX2,YY2,ARCY1)
 DEG2RAD=pi/180;  
 REARTH= 6371.0*1000; %m
%  TPI       = DEG2RAD*REARTH ; %!TPI=pi*rearth/180.=3.14159265/180.0*6371.*1000.

    if ( YY1 == YY2 ) 
       ARCY1=0.0;
    else
       X1=XX1*DEG2RAD;
       Y1=YY1*DEG2RAD;

       X2=XX2*DEG2RAD;
       Y2=YY2*DEG2RAD;

       YTMP  = Y2-Y1;
       if (YTMP >  PI) 
          YTMP = -2*PI+YTMP;
       elseif (YTMP < -pi ) 
          YTMP =  2*pi + YTMP;
       end

       ARCY1=REARTH*YTMP;
    end
% return
end
