function [node_p, ncel_p] = get_node_cell_id(Pr,Mesh);
%need: Pr.x, Pr.y, Mesh
%out1: Pr.nod =node_p;
%out2: Pr.cel =ncel_p;
%Pr.xx,Pr.yy.Pr.zz;
             tri=Mesh.tri;

  for i=1:length(Pr.x),...
          x0(i,1)=Pr.x(i);
          y0(i,1)=Pr.y(i);
    clear rr jc rmin dd xx yy zz ;
   for j=1:Mesh.Nverts,...
           clear dd xx yy ;
        xx=Mesh.x(j,1);
        yy=Mesh.x(j,2);
                    dd=sqrt( ((xx-x0(i))^2) +  ((yy-y0(i))^2) );
            rr(j,1)=dd;
%                                  la=[Mesh.geog(j,2), Pr.lat(i)];
%                                  lo=[Mesh.geog(j,1), Pr.lon(i)];
%       [dist,phaseangle]=sw_dist(la,lo,'km');
%             rd(j,1)=dist;
   end

       [rmin jc] =  min(rr);
%      [rMin jC] = sort(rd); Pr.nod(i,1)=jC(1);
    Pr.nod(i,1)=jc(1);
    Pr.xx(i,1)=Mesh.x(jc(1),1);
    Pr.yy(i,1)=Mesh.x(jc(1),2);
    Pr.zz(i,1)=Mesh.x(jc(1),3);
    Pr.rr(i,1)=rmin(1);
  end

x=Mesh.x(:,1);
y=Mesh.x(:,2);

  mark = ones(length(x),1);
          dims = size(Mesh.tri);
                 pts1=Pr.nod;
 for ii=1:length(pts1);
       i = pts1(ii);
 for j=1:dims(1);
   xtri = x(tri(j,1:3));
   ytri = y(tri(j,1:3));
    if(isintriangle(xtri,ytri,x(i),y(i)) ) ,...
     mark(i)    = 0;
   Pr.cel(ii,1) = j ;
   end;
 end;
 end;
 node_p=Pr.nod;
 ncel_p=Pr.cel;

end

