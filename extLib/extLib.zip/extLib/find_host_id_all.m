function [host,INDOMAIN,INWATER] = find_host_id_all(xt,yt,x0,y0,tri_id)
% dmitry.aleynik@sams.ac.uk 2011/08/18 ; based on peng fei LAG
global Mesh %CVM
%need: x0, y0, Mesh CVM; %
%out1: res     = result=1 OK     ; 0 = not found;
%out2: host  = new triangle id;
%out3: INDOMAIN; 1;
%out4: INWATER ; 1
%definitions:                           i=tri_id;
%                     tri=Mesh.trinodes(i,1:3);
%    xt = Mesh.nodexy(tri(1:3),1); yt = Mesh.nodexy(tri(1:3),2);
IFOUND = 0 ;
SBOUND = 0 ;
INDOMAIN=0 ;
INWATER =0 ;
host   = 0;
   NPTS=length(x0);
for J=1:NPTS,...
% get first location and node_p(1):

 if (isintriangle(xt,yt,x0(J),y0(J))) , ... % ==1, stay in the same triangle tri_id
       IFOUND(J) = 1      ;
         host(J) = tri_id ; %the same tiangle
     INDOMAIN(J) = 1;
     INWATER(J)  = 1;
 end
end

 if sum(IFOUND) ~= NPTS ,...
% then search only within 8 nearest triangles !
%% ============== check if in domain ?
    NV = Mesh.trinodes;
    VX = Mesh.nodexy(:,1);
    VY = Mesh.nodexy(:,2);
   NTVE = Mesh.ntve ; % loaded from .nc
   NBVE = Mesh.nbve';
 % [CVM] = isonb_m(CVM)
   ISONB= Mesh.isonb;
     XLAG  = x0;
     YLAG  = y0;

   for I=1:NPTS,...
%  if(INDOMAIN(I) == 0) cycle

   for j=1:Mesh.Nelems,...
           clear dd xc yc ;
        xc=Mesh.uvnode(j,1);
        yc=Mesh.uvnode(j,2);
                    dd=sqrt( ((xc-x0(J))^2) +  ((yc-y0(J))^2) );
            rr(j,1)=dd;
   end;
%        %[radlist   min_loc] =  min(rr);
          [Radlist   Min_loc] = sort(rr);
           radlast = 0;

 for in=1:8,...
  if  IFOUND(I)  ~= 1 ,...
      min_loc   = Min_loc(in);
        XTRI    =   VX(NV(min_loc,1:3)) ;
        YTRI    =   VY(NV(min_loc,1:3)) ;
        radlast = Radlist(in,1)  ;

     if(isintriangle(XTRI,YTRI,XLAG,YLAG)),...
       IFOUND(I)  = 1       ;
       host(I) = min_loc ;
            if(ISONB(NV(host(I),1)) == 1 || ISONB(NV(host(I),2)) == 1 || ISONB(NV(host(I),3)) == 1),...
                     SBOUND(I) = 1;
            else
                     SBOUND(I) = 0;
            end;
     end %if
  end;
 end; %in
%   if(sum(IFOUND) == sum(INDOMAIN)), all_found = .TRUE.

%%
   if (IFOUND(I) == 1 ),...
     INDOMAIN(I) = 1;
   end;

  if (IFOUND(I) == 0 && SBOUND(I) == 0)
     INDOMAIN(I) = 0;
  end;

  if (IFOUND(I) == 0 && SBOUND(I) == 1)
     INWATER(I) = 0;
  end;
 end; %I

 end; %if sum(ifound)

