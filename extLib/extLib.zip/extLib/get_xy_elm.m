function[OB]=get_xy_elm(xlon,xlat );
 global Mesh % CVM

   clear OB nod elm;
OB.lon=xlon;
OB.lat=xlat;
ProbN=length(OB.lon);j1=1;
x=Mesh.geog(:,1);
y=Mesh.geog(:,2);

 for jp=j1:ProbN ,...
    xn(jp,1)=OB.lon(jp,1);
    yn(jp,1)=OB.lat(jp,1);
    nod(jp,1)=1;
    clear radvec Distance Point tr0 ;
     xloc=xn(jp,1);yloc=yn(jp,1);
     radvec = sqrt( (xloc-x).^2 + (yloc-y).^2);
               [Distance,Point] = min(radvec);
        nod(jp,1)=Point;
               tr0=[];
               for ti=1:3,...
                       tr=[];
                       tr=find(Mesh.trinodes(:,ti)==Point);
                if ~isempty(tr),tr0(ti)=tr(1); end
               end
                              tr0=tr0(tr0>0);
                       tri_id=tr0(1);
                       host=tri_id;
                       tri = Mesh.trinodes(tr0(1),1:3);
    xtri = Mesh.nodexy(tri(1:3),1);
    ytri = Mesh.nodexy(tri(1:3),2);

     [host,INDOMAIN,INWATER] = find_host_id(xtri,ytri,xn(jp,1),yn(jp,1),tri_id);

        hos(jp,1)=host;
     if host > 0,...
      tri=Mesh.trinodes(host,:);
            dd=zeros(3,1); DD=[]; I=[];
      for jj=1:3
            dd(jj,1)=sqrt( ((Mesh.uvnode(tri(jj),1) - xn(jp,1))^2) ...
                        +  ((Mesh.uvnode(tri(jj),2) - yn(jp,1) )^2) );
      end
                  [DD,I]=min(dd);
      nod(jp,1)=tri( I(1) );
     else
        host=tri_id;
     end;

 OB.nod( jp,1) = nod(jp,1);
 OB.elm( jp,1) = host;
 OB.depth(jp,1) = Mesh.depth(OB.nod(jp,1)); % model bottm depth
%OB.name(jp,1:length( Ob{jp}.name))= Ob{jp}.name;
 end
%  OB.xn=xn;  OB.yn=yn;
%  pnod = OB.nod(:,1);
%  pelm = OB.elm(:,1);
% end
% OB.depths  = Mesh.depth(OB.nod)
