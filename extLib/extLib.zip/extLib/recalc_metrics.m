function [Mesh]  = recalc_metrics(tri,x)
%% already swaped the triangles according to ! LIST IS REORDERD! mode_input.F L3549:3552
% Mesh.tri_grd % remain as in _grd.dat, .2dm and SMS files - counter-clockwise order
% Mesh.tri     = Mesh.tri_grd(:,[1,3,2]); % reorderd elements in clockwise order as in FVCOM native nv
%
% (c) dmitry.aleynik@sams.ac.uk 2018.10.09;                               &
%  __o_O__�                                                               &
%  \_____/ ~~~~~~<@})))< ~ ~ ~~~~~ ~~~ SAMS                               &
%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
    SPHERICAL = true;
    if max(abs( x(:,2))) > 90,  SPHERICAL = false; end
    DEG2RAD = pi/180;   REARTH= 6371.0*1000; %m
    TPI       = DEG2RAD*REARTH ; %!TPI=pi*rearth/180.=3.14159265*6371.*1000./180.0

    fprintf('setting metrics\n')
    dims = size(tri);
    Nelems = dims(1);
    dims = size(x);
    Nverts = dims(1);
    geog=x(:,1:2);

    % calculate neighboring elements
    %calculate nbe, the element neighbors
    cells   = zeros(Nverts,10);
    cellcnt = zeros(Nverts,1);
    nbe     = zeros(Nelems,3);

    for i = 1:Nelems
        n1 = tri(i,1) ; cellcnt(n1) = cellcnt(n1) + 1;
        n2 = tri(i,2) ; cellcnt(n2) = cellcnt(n2) + 1;
        n3 = tri(i,3) ; cellcnt(n3) = cellcnt(n3) + 1;
        cells(tri(i,1),cellcnt(n1)) = i;
        cells(tri(i,2),cellcnt(n2)) = i;
        cells(tri(i,3),cellcnt(n3)) = i;
    end

    if(max(cellcnt) > 12)
        error('increase cells array')
    end

    for i = 1:Nelems
        n1 = tri(i,1); n2 = tri(i,2); n3 = tri(i,3);

        for j1 = 1:cellcnt(n1)
            for j2 = 1:cellcnt(n2)
                if((cells(n1,j1) == cells(n2,j2)) && cells(n1,j1) ~= i); nbe(i,3) = cells(n1,j1); end
            end
        end
        for j2 = 1:cellcnt(n2)
            for j3 = 1:cellcnt(n3)
                if((cells(n2,j2) == cells(n3,j3)) & cells(n2,j2) ~= i); nbe(i,1) = cells(n2,j2); end
            end
        end
        for j1 = 1:cellcnt(n1)
            for j3 = 1:cellcnt(n3)
                if((cells(n1,j1) == cells(n3,j3)) & cells(n1,j1) ~= i); nbe(i,2) = cells(n3,j3); end
            end
        end
    end

    %    save junk geog Nverts Nelems tri nbe
    fprintf('done nbe stuff\n')
    icnt = 0;
    bnodes = zeros(Nverts,1);
    bcells = zeros(Nelems,1);
    check  = floor(Nelems/10);
    for i=1:Nelems
        n1 = tri(i,1); n2 = tri(i,2); n3 = tri(i,3);
        if(nbe(i,1) == 0)
            icnt = icnt + 1;
            bnodes(n2) = 1; bnodes(n3) = 1; bcells(i) = 1;
            bndryx(icnt,1:2) = [geog(n2,1),geog(n3,1)];
            bndryy(icnt,1:2) = [geog(n2,2),geog(n3,2)];
        elseif(nbe(i,2) == 0)
            icnt = icnt + 1;
            bnodes(n3) = 1; bnodes(n1) = 1; bcells(i) = 1;
            bndryx(icnt,1:2) = [geog(n1,1),geog(n3,1)];
            bndryy(icnt,1:2) = [geog(n1,2),geog(n3,2)];
        elseif(nbe(i,3) == 0)
            icnt = icnt + 1;
            bnodes(n1) = 1; bnodes(n2) = 1; bcells(i) = 1;
            bndryx(icnt,1:2) = [geog(n1,1),geog(n2,1)];
            bndryy(icnt,1:2) = [geog(n1,2),geog(n2,2)];
        end
        if(mod(i,check)==0); fprintf('bnodes: completed %f percent \n',100*i/Nelems); end
    end
    nbndry = icnt;

    % determine edges
    Nedges = Nelems*3;
    edge = zeros(Nedges,2);
    icnt = 1;
    for i=1:Nelems
        edge(icnt  ,1:2) = tri(i,1:2);
        edge(icnt+1,1:2) = tri(i,2:3);
        edge(icnt+2,1:2) = tri(i,[3,1]);
        icnt = icnt + 3;
    end

    % determine nodes surrounding nodes (no specific order)
    ntsn = zeros(Nverts,1);
    nbsn = zeros(Nverts,12);

    for i=1:Nedges
        i1 = edge(i,1);
        i2 = edge(i,2);
        [lmin,loc] = min(abs(nbsn(i1,:)-i2));
        if (lmin ~= 0)
            ntsn(i1) = ntsn(i1)+1;
            nbsn(i1,ntsn(i1)) = i2;
        end
        [lmin,loc] = min(abs(nbsn(i2,:)-i1));
        if (lmin ~= 0)
            ntsn(i2) = ntsn(i2)+1;
            nbsn(i2,ntsn(i2)) = i1;
        end
    end

    %----DETERMINE MAX NUMBER OF SURROUNDING ELEMENTS------------------------------!

    if 1,...
        mx_nbr_elem = 0;
        fprintf('counting\n');
        check = floor(Nverts/10);
        for i=1:Nverts
            ncnt = 0;
            for j=1:Nelems
                if( (tri(j,1)-i)*(tri(j,2)-i)*(tri(j,3)-i) == 0.0 ), ...
                        ncnt = ncnt + 1;
                end
            end
            mx_nbr_elem = max(mx_nbr_elem,ncnt);
            if(mod(i,check)==0), fprintf('mx_nbr_elem: completed %f percent \n', 100*i/Nverts ); end
        end

        ntve = zeros(Nverts,1);
        nbve = zeros(Nverts,mx_nbr_elem+1);
        nbvt = zeros(Nverts,mx_nbr_elem+1);
        nbsn = zeros(Nverts,mx_nbr_elem+3);

        %--DETERMINE NUMBER OF SURROUNDING ELEMENTS FOR NODE I = NTVE(I)---------------!
        %--DETERMINE NBVE - INDICES OF NEIGHBORING ELEMENTS OF NODE I------------------!
        %--DETERMINE NBVT - INDEX (1,2, or 3) OF NODE I IN NEIGHBORING ELEMENT---------!

        for i=1:Nverts
            ncnt=0;
            for j=1:Nelems
                if ((tri(j,1)-i)*(tri(j,2)-i)*(tri(j,3)-i) == 0.0) ,...
                        ncnt = ncnt+1;
                    nbve(i,ncnt)=j;
                    if((tri(j,1)-i) == 0); nbvt(i,ncnt)=1; end
                    if((tri(j,2)-i) == 0); nbvt(i,ncnt)=2; end
                    if((tri(j,3)-i) == 0); nbvt(i,ncnt)=3; end
                end
            end
            ntve(i,1)=ncnt;
        end
        fprintf('doing nbsn ');

        %--Reorder Order Elements Surrounding a Node to Go in a Cyclical Procession----!
        %--Determine NTSN  = Number of Nodes Surrounding a Node (+1)-------------------!
        %--Determine NBSN  = Node Numbers of Nodes Surrounding a Node------------------!

        nb_tmp = zeros(Nverts,mx_nbr_elem+1);

        check = floor(Nverts/10);
        for i=1:Nverts
            if(bnodes(i) == 0),...
                nb_tmp(1,1)=nbve(i,1);
                nb_tmp(1,2)=nbvt(i,1);
                for j=2:ntve(i)+1
                    ii=nb_tmp(j-1,1);
                    jj=nb_tmp(j-1,2);
                    nb_tmp(j,1)=nbe(ii,jj+1-floor((jj+1)/4)*3);
                    jj=nb_tmp(j,1);
                    % TPA added condition 11/10/2018 to ignore "erroneous elements"
                    if (jj~=0)
                        if((tri(jj,1)-i) == 0); nb_tmp(j,2)=1; end
                        if((tri(jj,2)-i) == 0); nb_tmp(j,2)=2; end
                        if((tri(jj,3)-i) == 0); nb_tmp(j,2)=3; end
                    end
                end

                for j=2:ntve(i)+1
                    nbve(i,j)=nb_tmp(j,1);
                end

                for j=2:ntve(i)+1
                    nbvt(i,j)=nb_tmp(j,2);
                end

                ntmp=ntve(i)+1;
                ntsn(i)=ntve(i);

                for j=1:ntsn(i)
                    ii=nbve(i,j);
                    jj=nbvt(i,j);
                    nbsn(i,j)=tri(ii,jj+1-floor((jj+1)/4)*3);
                end

                ntsn(i)=ntsn(i)+1;
                nbsn(i,ntsn(i))=nbsn(i,1);

            else
                jjb=0;

                for j=1:ntve(i)
                    jj=nbvt(i,j);
                    if(nbe(nbve(i,j),jj+2-floor((jj+2)/4)*3) == 0)
                        jjb=jjb+1;
                        nb_tmp(jjb,1)=nbve(i,j);
                        nb_tmp(jjb,2)=nbvt(i,j);
                    end
                end

                for j=2:ntve(i)
                    ii=nb_tmp(j-1,1);
                    jj=nb_tmp(j-1,2);
                    nb_tmp(j,1)=nbe(ii,jj+1-floor((jj+1)/4)*3);
                    jj=nb_tmp(j,1);
                    if((tri(jj,1)-i) == 0); nb_tmp(j,2)=1; end
                    if((tri(jj,2)-i) == 0); nb_tmp(j,2)=2; end
                    if((tri(jj,3)-i) == 0); nb_tmp(j,2)=3; end
                end

                for j=1:ntve(i)
                    nbve(i,j)=nb_tmp(j,1);
                    nbvt(i,j)=nb_tmp(j,2);
                end

                nbve(i,ntve(i)+1)=0;
                ntsn(i)=ntve(i)+1;
                nbsn(i,1)=i;

                for j=1:ntsn(i)-1
                    ii=nbve(i,j);
                    jj=nbvt(i,j);
                    nbsn(i,j+1)=tri(ii,jj+1-floor((jj+1)/4)*3);
                end

                j=ntsn(i);
                ii=nbve(i,j-1);
                jj=nbvt(i,j-1);
                nbsn(i,j+1)=tri(ii,jj+2-floor((jj+2)/4)*3);
                ntsn(i)=ntsn(i)+2;
                nbsn(i,ntsn(i))=i;
            end
            if(mod(i,check)==0); fprintf('completed %f percent \n',100*i/Nverts); end
        end
    end
    %% ---------------------
    clear nb_tmp

    Mesh.Nbndry = nbndry;
    Mesh.Nelems = Nelems;
    Mesh.Nverts = Nverts;
    Mesh.tri  = tri;
    Mesh.x    = x;
    Mesh.geog = geog;
    Mesh.nbe  = nbe;

    Mesh.bndryx = bndryx;
    Mesh.bndryy = bndryy;

    Mesh.bcells = (bcells);
    Mesh.bnodes = (bnodes);
    Mesh.nbsn   =  (nbsn);
    Mesh.ntsn   =  (ntsn);
    Mesh.ntve   =  (ntve);
    Mesh.nbve   =  (nbve);
    Mesh.nbvt   =  (nbvt);
    Mesh.trinodes = Mesh.tri;
    Mesh.nodexy   = Mesh.geog(:,1:2);

    Nelems = Mesh.Nelems;
    Nverts = Mesh.Nverts;
    Mesh.depth = Mesh.x(:,3);

    %form u,v locations (the centroid of triangle)
    uvnode=zeros(Nelems,2);  uvdepth=zeros(Nelems,1);
    for n=1:Nelems
        uvnode(n,1)=(Mesh.nodexy(Mesh.trinodes(n,1),1)+...
            Mesh.nodexy(Mesh.trinodes(n,2),1)+...
            Mesh.nodexy(Mesh.trinodes(n,3),1))/3;
        uvnode(n,2)=(Mesh.nodexy(Mesh.trinodes(n,1),2)+...
            Mesh.nodexy(Mesh.trinodes(n,2),2)+...
            Mesh.nodexy(Mesh.trinodes(n,3),2))/3;
        uvdepth(n)=(Mesh.depth(Mesh.trinodes(n,1))+...
            Mesh.depth(Mesh.trinodes(n,2))+...
            Mesh.depth(Mesh.trinodes(n,3)))/3;
    end
    Mesh.uvnode=uvnode;
    Mesh.uvdepth=uvdepth;

    %% ==============
    nv  = Mesh.trinodes;
    nbe = Mesh.nbe   ; %  nbe  % "elements surrounding each element" ;nbe!!INDICES OF ELMNT NEIGHBORS
    M = Mesh.Nverts;
    N = Mesh.Nelems;
    isbce=zeros(1,N);
    isonb=zeros(1,M);
    for I=1:N ,...
        if(min(min(nbe(I,1),nbe(I,2)), nbe(I,3))==0) ,...  % !!ELEMENT ON BOUNDARY
            isbce(I) = 1;
            if(nbe(I,1) == 0),...
                isonb(nv(I,2)) = 1 ; isonb(nv(I,3)) = 1;
            end
            if(nbe(I,2) ==0) ,...
                isonb(nv(I,1)) = 1 ; isonb(nv(I,3)) = 1;
            end
            if(nbe(I,3) ==0) ,...
                isonb(nv(I,1)) = 1 ; isonb(nv(I,2)) = 1;
            end
        end
    end
    Mesh.isonb = isonb';
    Mesh.isbce = isbce';

    % art == area of element (triangle) art=zeros(N,1);
    %
    % we should use cells_area in a case of 'spherical'
    if 1,...
        fprintf('doing DLTXYE ');

        %!  VX(M)    !!X-COORD AT GRID POINT Mesh.uvnode = 1/3(sum(x(nv(i),:);
        %!  VY(M)    !!Y-COORD AT GRID POINT
        %!  xc(N)    :: xc(i) = x-coordinate of element i (calculated from vx) !X-COORD AT FACE CENTER
        %!  yc(N)    :: yc(i) = y-coordinate of element i (calculated from vy) !Y-COORD AT FACE CENTER
        %!  xijc(ne)  :: xijc(i) = x-coordinate of mid point of element edge i !
        %!  yijc(ne)  :: yijc(i) = y-coordinate of mid point of element edge i !

        XC(:,1)= Mesh.uvnode(:,1); % at x-coord of cell centroids
        YC(:,1)= Mesh.uvnode(:,2); % YC=FVCOM.yc ; XC=FVCOM.xc ;
        VX(:,1)= Mesh.nodexy(:,1);
        VY(:,1)= Mesh.nodexy(:,2);
        nbe = Mesh.nbe   ;
        nv  = Mesh.tri   ; % clock-wise   as in fvcom
        NCV = N+3*N; %max Number
        NE   = 0;    % :    number of unique element edges (not yet known)!
        ISET=zeros(N,3); TEMP=zeros(N*3,2); TEMP2=zeros(N*3,2);
        for  I=1:N,...
            for J=1:3,...
                if(ISET(I,J) == 0)
                NE   = NE + 1;
                INEY = nbe(I,J);
                ISET(I,J) = 1;
                for JN =1:3,...
                        if INEY~=0 && I == nbe(INEY,JN), ISET(INEY,JN) = 1 ; end
                end
                TEMP(NE,1) = I ;   %iec .,1
                TEMP(NE,2) = INEY; %iec .,2
                J1= J+1 - fix((J+1)/4)*3 ;
                J2= J+2 - fix((J+2)/4)*3 ;
                TEMP2(NE,1) = nv(I, J1 ); %ienode
                TEMP2(NE,2) = nv(I, J2 ); % int8== jfix (round) truncate to integer
                end
            end
        end
        IEC(:,1)    = TEMP(1:NE,1)  ;
        IEC(:,2)    = TEMP(1:NE,2)  ;
        IENODE(:,1) = TEMP2(1:NE,1) ;
        IENODE(:,2) = TEMP2(1:NE,2) ;

        clearvars TEMP TEMP2 INEY JN I J;

        NIEC =zeros(NE,2); NTRG =zeros(NE,1);
        DLTXE=zeros(NE,1); DLTYE=zeros(NE,1); DLTXYE=zeros(NE,1);
        XIJC =zeros(NE,1); YIJC =zeros(NE,1);
        XIJE =zeros(NE,1); YIJE =zeros(NE,1);

        ISBC=zeros(NE,1); % Is the element on the boundary?
        if  (SPHERICAL),...
                for I=1:NE
                X1_DP=VX(IENODE(I,1));
                Y1_DP=VY(IENODE(I,1));
                X2_DP=VX(IENODE(I,2));
                Y2_DP=VY(IENODE(I,2));

                [XXC,YYC ]= arcc(X2_DP,Y2_DP,X1_DP,Y1_DP);
                %   [side]    = arcx(X1_DP,Y1_DP,X2_DP,Y2_DP);
                %      XTMP  = VX(IENODE(I,2))*TPI-VX(IENODE(I,1))*TPI;
                %      XTMP1 = VX(IENODE(I,2))-VX(IENODE(I,1));
                %      if (XTMP1 > 180.0 ), ...
                %        XTMP = -360.0 *TPI+XTMP;
                %      elseif (XTMP1 < -180.0 ), ...
                %        XTMP = 360.0 *TPI+XTMP;
                %      end
                %      DLTXC(I) =XTMP*cos(DEG2RAD*(VY(IENODE(I,2))+VY(IENODE(I,1)))*0.5 );
                %      DLTYC(I) =(VY(IENODE(I,2))-VY(IENODE(I,1)))*TPI;
                %      [side] = arc(X1_DP, Y1_DP, X2_DP, Y2_DP);
                %      DLTXYC(I) = side;
                %      SITAC(I) =atan2(DLTYC(I),DLTXC(I));
                XIJC(I)=XXC;
                YIJC(I)=YYC;
                %!------MARK ELEMENT EDGES THAT ARE ON THE BOUNDARY-:
                if (IEC(I,1) == 0) || (IEC(I,2) == 0) ,  ISBC(I) = 1 ; end
                end
        else
            for I=1:NE,...
                    XIJC(I,1)  = (VX(IENODE(I,1))+VX(IENODE(I,2)))/2.0;
                YIJC(I,1)  = (VY(IENODE(I,1))+VY(IENODE(I,2)))/2.0;
                %!------MARK ELEMENT EDGES THAT ARE ON THE BOUNDARY-:
                if (IEC(I,1) == 0) || (IEC(I,2) == 0) ,  ISBC(I) = 1 ; end
            end
        end %spherical
        %% ======================2
        NCTMP  = 0 ;   NCETMP = 0 ;
        for I=1:NE,...
                if (ISBC(I) == 0),...
                    if(IEC(I,1) <= N),...
                        NCTMP=NCTMP+1;
                    NPT  =NCTMP;
                    else
                        NCETMP = NCETMP + 1;
                        NPT    = NCETMP+(3*N);
                    end

                    XIJE(NPT,1) = XC(IEC(I,1)) ;
                    YIJE(NPT,1) = YC(IEC(I,1)) ;
                    XIJE(NPT,2) = XIJC(I)      ;
                    YIJE(NPT,2) = YIJC(I)      ;
                    NIEC(NPT,1) = IENODE(I,1)  ;
                    NIEC(NPT,2) = IENODE(I,2)  ;
                    NTRG(NPT,1)   = IEC(I,1)   ;
                    DLTXE(NPT,1)  = XIJE(NPT,2)-XIJE(NPT,1);
                    DLTYE(NPT,1)  = YIJE(NPT,2)-YIJE(NPT,1);

                    if (SPHERICAL),
                        X1_DP=XIJE(NPT,1);
                        Y1_DP=YIJE(NPT,1);
                        X2_DP=XIJE(NPT,2);
                        Y2_DP=YIJE(NPT,2);
                        [XXC,YYC ]= arcc(X2_DP,Y2_DP,X1_DP,Y1_DP);
                        % for global case when VX change from 360 to 0 or from 0 to 360 (degree)
                        XTMP  = XIJE(NPT,2)*TPI-XIJE(NPT,1)*TPI;
                        XTMP1 = XIJE(NPT,2)-XIJE(NPT,1);
                        if (XTMP1 >  180.0 ),...
                                XTMP = -360.0 *TPI+XTMP;
                        elseif (XTMP1 < -180.0 ),...
                                XTMP =  360.0 *TPI+XTMP;
                        end

                        DLTXE(NPT)=XTMP*cos(DEG2RAD*Y1_DP);
                        DLTYE(NPT)=TPI*DLTYE(NPT);
                        [DTMP_DP] = arc(X1_DP, Y1_DP, X2_DP, Y2_DP);

                        DLTXYE(NPT)=DTMP_DP;
                        SITAE(NPT)=atan2(DLTYE(NPT),DLTXE(NPT));
                        DLTXNE(I,1) = DLTXE(NPT);
                        DLTYNE(I,1) = DLTYE(NPT);
                    else
                        DTMP        = DLTXE(NPT)*DLTXE(NPT)+DLTYE(NPT)*DLTYE(NPT);
                        DLTXYE(NPT) = sqrt(DTMP);
                        SITAE(NPT)  = atan2(DLTYE(NPT),DLTXE(NPT));
                    end %spherical

                    if (IEC(I,2) <= N),...
                            NCTMP=NCTMP+1 ;
                        NPT  =NCTMP   ;
                    else
                        NCETMP = NCETMP + 1   ;
                        NPT    = NCETMP+(3*N) ;
                    end

                    XIJE(NPT,1) = XC(IEC(I,2));
                    YIJE(NPT,1) = YC(IEC(I,2));
                    XIJE(NPT,2) = XIJC(I)     ;
                    YIJE(NPT,2) = YIJC(I)     ;
                    NIEC(NPT,1) = IENODE(I,2) ;
                    NIEC(NPT,2) = IENODE(I,1) ;
                    NTRG(NPT,1)   = IEC(I,2)  ;
                    DLTXE(NPT,1)  = XIJE(NPT,2)-XIJE(NPT,1);
                    DLTYE(NPT,1)  = YIJE(NPT,2)-YIJE(NPT,1);
                    if (SPHERICAL), ...
                            X1_DP=XIJE(NPT,1);
                        Y1_DP=YIJE(NPT,1);
                        X2_DP=XIJE(NPT,2);
                        Y2_DP=YIJE(NPT,2);

                        [XXC,YYC ]= arcc(X2_DP,Y2_DP,X1_DP,Y1_DP);

                        %  for global case when VX change from 360 to 0 or from 0 to 360 (degree)
                        XTMP  = XIJE(NPT,2)*TPI-XIJE(NPT,1)*TPI;
                        XTMP1 = XIJE(NPT,2)-XIJE(NPT,1);
                        if (XTMP1 >  180.0  ), ...
                                XTMP = -360.0 *TPI+XTMP;
                        elseif(XTMP1 < -180.0 ), ...
                                XTMP =  360.0 *TPI+XTMP;
                        end
                        DLTXE(NPT)=XTMP*cos(DEG2RAD*Y1_DP);
                        DLTYE(NPT) =TPI*DLTYE(NPT);

                        [DTMP_DP] = arc(X1_DP, Y1_DP, X2_DP, Y2_DP);

                        DLTXYE(NPT)= DTMP_DP;
                        SITAE(NPT) = atan2(DLTYE(NPT),DLTXE(NPT));
                        DLTXNE(I,2) = DLTXE(NPT);
                        DLTYNE(I,2) = DLTYE(NPT);
                    else
                        DTMP =DLTXE(NPT)*DLTXE(NPT)+DLTYE(NPT)*DLTYE(NPT);
                        DLTXYE(NPT)= sqrt(DTMP);
                        SITAE(NPT) = atan2(DLTYE(NPT),DLTXE(NPT));
                    end %spherical

                elseif(ISBC(I) == 1) , ...
                    if(IEC(I,1) <= N),...
                        NCTMP=NCTMP+1;
                        NPT  =NCTMP;
                    else
                        NCETMP = NCETMP + 1  ;
                        NPT    = NCETMP+(3*N);
                    end

                    if(IEC(I,1) == 0) ,...
                        disp([ num2str(I), 'IEC(I,1)===0  ! error in Mesh !'])
                        stop ;%exit
                    end

                    XIJE(NPT,1) = XC(IEC(I,1))  ;
                    YIJE(NPT,1) = YC(IEC(I,1))  ;
                    XIJE(NPT,2) = XIJC(I)       ;
                    YIJE(NPT,2) = YIJC(I)       ;
                    NIEC(NPT,1) = IENODE(I,1)   ;
                    NIEC(NPT,2) = IENODE(I,2)   ;
                    NTRG(NPT,1) = IEC(I,1)      ;
                    DLTXE(NPT,1)= XIJE(NPT,2)-XIJE(NPT,1);
                    DLTYE(NPT,1)= YIJE(NPT,2)-YIJE(NPT,1);
                    if  (SPHERICAL),...
                            X1_DP= XIJE(NPT,1);
                        Y1_DP= YIJE(NPT,1);
                        X2_DP= XIJE(NPT,2);
                        Y2_DP= YIJE(NPT,2);

                        [XXC,YYC ]= arcc(X2_DP,Y2_DP,X1_DP,Y1_DP);

                        % for global case when VX change from 360 to 0 or from 0 to 360 (degree)
                        XTMP  = XIJE(NPT,2)*TPI-XIJE(NPT,1)*TPI;
                        XTMP1 = XIJE(NPT,2)-XIJE(NPT,1);
                        if(XTMP1 >  180.0 ),...
                            XTMP = -360.0 *TPI+XTMP;
                        elseif (XTMP1 < -180.0 ),...
                            XTMP =  360.0 *TPI+XTMP;
                        end
                        DLTXE(NPT)=XTMP*cos(DEG2RAD*Y1_DP);
                        DLTYE(NPT)=TPI*DLTYE(NPT);

                        [DTMP_DP] = arc(X1_DP, Y1_DP, X2_DP, Y2_DP);

                        DLTXYE(NPT)=DTMP_DP;
                        SITAE(NPT) =atan2(DLTYE(NPT),DLTXE(NPT));
                        DLTXNE(I,1) = DLTXE(NPT);
                        DLTYNE(I,1) = DLTYE(NPT);
                        DLTXNE(I,2) = 0.0;
                        DLTYNE(I,2) = 0.0;
                    else
                        DTMP=DLTXE(NPT)*DLTXE(NPT)+DLTYE(NPT)*DLTYE(NPT);
                        DLTXYE(NPT)=sqrt(DTMP);
                        SITAE(NPT)=atan2(DLTYE(NPT),DLTXE(NPT));
                    end %spherical

                else
                    disp([  'ISBC(I) NOT CORRECT, I==', num2str(I) ])
                    stop; %exit
                end % ISBC(I)
        end
        NCV= NCETMP+NCTMP;
        %% =================== do we need that ?
        Mesh.XIJE  =       XIJE  ;
        Mesh.YIJE  =       YIJE  ;
        Mesh.DLTXE =       DLTXE ; % the x distance of individual edges
        Mesh.DLTYE =       DLTYE ;
        Mesh.DLTXYE =     DLTXYE ; % the length of individual edges
        Mesh.XIJC  =        XIJC ;
        Mesh.YIJC  =        YIJC ;

        Mesh.ne   =          NE  ;
        Mesh.iec   =         IEC ;
        Mesh.ienode =     IENODE ;
        Mesh.ncv   =       NCV   ;
        Mesh.niec  =       NIEC  ;
        Mesh.ntrg  =       NTRG  ;
    end
end