function [host,INDOMAIN,INWATER] = find_host_id(xt,yt,x0,y0,tri_id)
% dmitry.aleynik@sams.ac.uk 2011/08/18 ; based on peng fei LAG
global Mesh %CVM
%need: x0, y0, Mesh CVM; %
%out1: res     = result=1 OK     ; 0 = not found;
%out2: host  = new triangle id;
%out3: INDOMAIN; 1;
%out4: INWATER ; 1
%definitions:                           i=tri_id;
%                     tri=Mesh.trinodes(i,1:3);
%    xt = Mesh.nodexy(tri(1:3),1); yt = Mesh.nodexy(tri(1:3),2);
IFOUND = 0 ;
SBOUND = 0 ;
INDOMAIN=1 ;
INWATER =1 ;
host   = 0;
% get first location and node_p(1):
 if (isintriangle(xt,yt,x0,y0)) , ... % ==1, stay in the same triangle tri_id
       IFOUND = 1      ;
       host   = tri_id ; %the same tiangle
 end
 if IFOUND == 0 ,...
% then search only within 8 nearest triangles !
%% ============== check if in domain ?
   NV = Mesh.trinodes;
    VX = Mesh.nodexy(:,1);
    VY = Mesh.nodexy(:,2);
%    NTVE = CVM.ntve ; % loaded from .nc
%    NBVE = CVM.nbve';
%  % [CVM] = isonb_m(CVM)
   ISONB= Mesh.isonb;
     XLAG  = x0;
     YLAG  = y0;

%          NPTS=length(x0);
%   for I=1:NPTS,...
 % if(INDOMAIN(I) == 0) return %cycle
   rr=zeros(Mesh.Nelems,1);
              rr(:,1)=sqrt( ((Mesh.uvnode(:,1)-x0).^2) +  ((Mesh.uvnode(:,2)-y0).^2) );

          [Radlist   Min_loc] = sort(rr);

 %for in=1:Mesh.Nelems,
 for in=1:8,...

  if  IFOUND  ~= 1 ,...
      min_loc   = Min_loc(in);
        XTRI    =   VX(NV(min_loc,1:3)) ;
        YTRI    =   VY(NV(min_loc,1:3)) ;
        radlast = Radlist(in,1)  ;

     if(isintriangle(XTRI,YTRI,XLAG,YLAG)),...
       IFOUND  = 1       ;
       host    = min_loc ;
            if(ISONB(NV(host,1)) == 1 || ISONB(NV(host,2)) == 1 || ISONB(NV(host,3)) == 1),...
                     SBOUND = 1;
            else
                     SBOUND = 0;
            end;
     end %if
  end;
 end; %in
 %   if(sum(IFOUND) == sum(INDOMAIN)), all_found = .TRUE.
 end;
%%
   if (IFOUND == 1 ),...
     INDOMAIN = 1;
   end;

  if (IFOUND == 0 && SBOUND == 0)
     INDOMAIN = 0;
  end;

  if (IFOUND == 0 && SBOUND == 1)
     INWATER = 0;
  end;


%end;
