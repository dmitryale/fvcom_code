function [host,INDOMAIN,INWATER] = find_host_id_fast(xt,yt,x0,y0,tri_id)
% dmitry.aleynik@sams.ac.uk 2011/08/18 ; based on peng fei LAG routine
global Mesh % CVM
%need: xt,yt, x0, y0, tri_id, Mesh, CVM;
%out1: host  = new triangle id;
%out2: INDOMAIN; 1;
%out3: INWATER ; 1
%definitions:                           i=tri_id;
%                     tri=Mesh.trinodes(i,1:3);
%    xt = Mesh.nodexy(tri(1:3),1); yt = Mesh.nodexy(tri(1:3),2);
IFOUND = 0 ;
SBOUND = 0 ;
INDOMAIN=1 ;
INWATER =1 ;
host    =0 ;
% get first location and node_p(1):
 if (isintriangle(xt,yt,x0,y0)) , ... % ==1, stay in the same triangle tri_id
       IFOUND = 1      ;
       host   = tri_id ; %the same tiangle
 end
 if IFOUND == 0 ,...
% then search only within 8 nearest triangles !
%% ============== check if in domain ?
   NV = Mesh.trinodes;
   VX = Mesh.nodexy(:,1);
   VY = Mesh.nodexy(:,2);
   NTVE = Mesh.ntve ; % loaded from .nc
   NBVE = Mesh.nbve';
 % [CVM] = isonb_m(CVM)
   ISONB= Mesh.isonb;

     XLAG  = x0;
     YLAG  = y0;
     ILAST = tri_id;         % HOST(I)

     XLAST = VX(NV(ILAST,1:3));
     YLAST = VY(NV(ILAST,1:3));

     if(isintriangle(XLAST,YLAST,XLAG,YLAG)),... %!!PARTICLE REMAINS IN ELEMENT
       IFOUND  = 1   ;
       host = tri_id ; %the same tiangle (wet)
     else                                             %!!CHECK NEIGHBORS
        for J=1:3,...
          if  IFOUND ~= 1 ,...
           NCHECK = NV(ILAST,J);
           for K=1:NTVE(NV(ILAST,J)),...  % number of "elems surrounding each node" ;
            if  IFOUND ~= 1 ,...
              INEY = NBVE(NCHECK,K)  ;    % INDICIES OF ELEMENTS SURROUNDING EACH NODE
              XNEY = VX(NV(INEY,1:3));
              YNEY = VY(NV(INEY,1:3));
              if(isintriangle(XNEY,YNEY,XLAG,YLAG)),...
                 IFOUND  = 1   ;
                 host    = INEY; %HOST(I) % new host !
               if(ISONB(NV(INEY,1)) == 1 || ISONB(NV(INEY,2)) == 1 || ISONB(NV(INEY,3)) == 1),...
                     SBOUND = 1;
               else
                     SBOUND = 0;
               end;
              end;
            end
           end; %K
          end
        end; %J
     end
%   if(sum(IFOUND) == sum(INDOMAIN)), all_found = .TRUE.
 end;
%%
  if (IFOUND == 1 ),...
     INDOMAIN = 1;
  end;

  if (IFOUND == 0 && SBOUND == 0)
     INDOMAIN = 0;
  end;

  if (IFOUND == 0 && SBOUND == 1)
     INWATER = 0;
  end;
%end;
