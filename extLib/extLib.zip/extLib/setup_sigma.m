%setup_sigma.m is based on fvcom's mod_setup.F subroutine sigma_geometric
function[Z,ZZ,ZZ1,DZ,DZ1] = setup_sigma(INDEX_VERCOR, P_SIGMA, KSL, KB, zl, DU2,DL2,Mesh)
%setup_sigma(INDEX_VERCOR,P_SIGMA, KSL, KB, zl,DU2,DL2);
% call it as: [ZZ,ZZ1,DZ,DZ1] = setup_sigma(INDEX_VERCOR,P_SIGMA, KSL, KB, zl,DU2,DL2);

%   INDEX_VERCOR=2; % INDEX_VERCOR=1;%   INDEX_VERCOR=2; % INDEX_VERCOR=3;
%    P_SIGMA=2.0 ;  %P_SIGMA=1.0 ;
%      KSL = ksl;   % number of Z standard levels
%   DPTHSL = zl;    % m
%        KB=KB1+1;    % number of sigma levels, must be odd KB=15
%  %DU2 = 0.001; DL2 = 0.001; %DEFAULT equal; %DU2 = 0.200; DL2 = 2.000; % condesed near bottom
%   DU2 = 2.000; DL2 = 2.000; % condesed near surface and bottom

 IDX=INDEX_VERCOR;
 N =Mesh.Nelems; % number of elements (triangles' centroids)
 M =Mesh.Nverts; % number of nodes    (vertices <| )
 if exist('Mesh.tri','var')~=1,...
     Mesh.tri=Mesh.trinodes;
 end
 NV=Mesh.tri   ;  % NV(1:N,3);   % NODE NUMBERING FOR ELEMENTS (0:NT)

 if exist('Mesh.x','var')~=1,...
     Mesh.x(:,1:2)=Mesh.nodexy(:,1:2);
     Mesh.x(:,3)  =Mesh.depth;
 end

  D=Mesh.x(:,3);    % depth at nodes
KBM1= KB-1;
   ZTMP=zeros(KB,1);
      Z=zeros(M,KB);
     Z1=zeros(N,KB);
     D3n=zeros(M,KB);
     D3c=zeros(N,KB);
     Dc =zeros(N,1);
% case (1):
if IDX==1, ...
  if P_SIGMA == 1,...
   for K=1:KB, ...
       ZTMP(K,1) = -((K-1)/(KB-1))^P_SIGMA ;
   end;
  else
   for K=1:(KB+1)/2,...
       ZTMP(K) = -((K-1)/((KB+1)/2-1) )^P_SIGMA/2 ;
   end
   for K=((KB+1)/2)+1 : KB,...
       ZTMP(K) =  ((KB-K)/((KB+1)/2-1) )^P_SIGMA/2 - 1.0 ;
   end
  end;

   for J=1:M,...
     for K=1:KB,...
       Z(J,K)=ZTMP(K);
     D3n(J,K)=D(J)*Z(J,K);  %depth at nods   DEPTH_Z(K)=Z(I,K)*D(I) !LAYER CENTER DEPTH
     end;
   end;

   for I=1:N,...
       Dc(I)  =(D(NV(I,1) )+D(NV(I,2)  )+ D(NV(I,3)  )) / 3.0 ;
     for K=1:KB,...
       Z1(I,K)=(Z(NV(I,1),K)+Z(NV(I,2),K)+ Z(NV(I,3),K)) / 3.0 ;
      D3c(I,K)=Dc(I)*Z1(I,K);  %depth at centroids
     end;
   end;
end;
%%  case (ii)
if IDX==2,...

   for K=1:KBM1,...
     X1=DL2+DU2;
     X1=X1*(KBM1-K)/KBM1;
     X1=X1-DL2;
     X1=tanh(X1);
     X2=tanh(DL2);
     X3=X2+tanh(DU2);
     for J=1:M,...
        Z(J,K+1)=(X1+X2)/X3 - 1.0;
     end;
     for I=1:N,...
       Z1(I,K+1)=(X1+X2)/X3 - 1.0;
     end;
   end;

   for K=1:KB,...
     for J=1:M,...
     D3n(J,K)=D(J)*Z(J,K);  %depth at nods !LAYER CENTER DEPTH
     end;

      for I=1:N,...
    if K==1,    Dc(I)=(D(NV(I,1) )+D(NV(I,2)  )+ D(NV(I,3)  )) / 3.0 ;  end;
      D3c(I,K)=Dc(I)*Z1(I,K);  %depth at centroids
      end;
   end;

end;
%% derivatives :
for K=1:KB-1,...
     for I=1:M,...
       ZZ(I,K)  = 0.5*(Z(I,K)+Z(I,K+1));
       DZ(I,K)  = Z(I,K)-Z(I,K+1);
     end;
     for I=1:N,...
       DZ1(I,K)  = Z1(I,K)-Z1(I,K+1);
       ZZ1(I,K)  = 0.5*(Z1(I,K)+Z1(I,K+1));
     end;
end;
   for I=1:M,...
     ZZ(I,KB) = 2.0*ZZ(I,KB-1)-ZZ(I,KB-2);
   end;
   for I=1:N,...
     ZZ1(I,KB) = 2.0*ZZ1(I,KB-1)-ZZ1(I,KB-2);
   end;

     KBM2=KB-2;
       for K=1:KBM2,
       for I=1:M,
          DZZ(I,K) = ZZ(I,K)-ZZ(I,K+1);
       end
       for I=1:N,
          DZZ1(I,K) = ZZ1(I,K)-ZZ1(I,K+1);
       end
       end

    DZZ(:,KBM1) = 0.0;
    DZ(:,KB)    = 0.0;
    DZZ1(:,KBM1) = 0.0;
    DZ1(:,KB)    = 0.0;

end
%% ------

