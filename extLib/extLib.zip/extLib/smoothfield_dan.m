function [field]  = smoothfield_dan(fieldin,Mesh,pts,fac,loops)
%loops=1;fac=0.95; fieldin=[]; fieldin=var(:,iz);
field = fieldin;
for ll=1:loops;
for ii=1:length(pts)
  i = pts(ii);
  ss = 0.;
  fieldo=[]; nfo=[];
  fieldo = fieldin(Mesh.nbsn(i,1 : Mesh.ntsn(i) ) );

     nfo = find(fieldo>0)       ;
 if isempty(nfo)~=1,...
  for k=1:Mesh.ntsn(i);
    node = Mesh.nbsn(i,k);
%!da
         if (fieldin(node) >0 )
%    ss = ss +  fieldin(node)/real(Mesh.ntsn(i));
     ss = ss +  fieldin(node)/(length(nfo));
         end
  end;
  fieldin(i) = (1-fac)*fieldin(i) + fac*ss;
 end;
end;
end;
field = fieldin;
