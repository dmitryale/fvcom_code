   function [Mesh1]=Mesh_bndryx(Mesh)

   Nverts=Mesh.Nverts;
   Nelems=Mesh.Nelems;
   tri   =Mesh.tri;
   geog  =Mesh.geog;
      nbe=Mesh.nbe ;% CVM.nbe;

   bnodes = zeros(Nverts,1);
   bcells = zeros(Nelems,1);
   check  = floor(Nelems/100);
   icnt=0;
   for i=1:Nelems
      n1 = tri(i,1); n2 = tri(i,2); n3 = tri(i,3);
      if(nbe(i,1) == 0)
        icnt = icnt + 1;
        bnodes(n2) = 1; bnodes(n3) = 1; bcells(i) = 1;
        bndryx(icnt,1:2) = [geog(n2,1),geog(n3,1)];
        bndryy(icnt,1:2) = [geog(n2,2),geog(n3,2)];
      elseif(nbe(i,2) == 0)
        icnt = icnt + 1;
        bnodes(n3) = 1; bnodes(n1) = 1; bcells(i) = 1;
        bndryx(icnt,1:2) = [geog(n1,1),geog(n3,1)];
        bndryy(icnt,1:2) = [geog(n1,2),geog(n3,2)];
      elseif(nbe(i,3) == 0)
        icnt = icnt + 1;
        bnodes(n1) = 1; bnodes(n2) = 1; bcells(i) = 1;
        bndryx(icnt,1:2) = [geog(n1,1),geog(n2,1)];
        bndryy(icnt,1:2) = [geog(n1,2),geog(n2,2)];
      end;
%        if(mod(i,check)==0); fprintf('bnodes: completed %f percent \n',100*i/Nelems); end;
   end;
   nbndry = icnt;
        if(mod(i,check)==0); fprintf('bnodes: completed %f percent \n',100*i/Nelems); end;

   Mesh.bndryx=bndryx;
   Mesh.bndryy=bndryy;
   Mesh.bnodes=bnodes;
   Mesh1=Mesh;
   end