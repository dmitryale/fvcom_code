function newmap=redbluecolmap(min,max)
if min>0 | max<0
   disp('caxis range must be (-ve,+ve)')
   %break
end
n=ones(64,3);

piv=round(64*abs(min/(min-max)))+1; % find the index for the zero value
ipiv=64-piv+2;
% now make the colormap
n(1:piv-1,1)=[0:(1/(piv-2)):1]';
n(piv-2:64,3)=[1:-(1/(ipiv)):0]';
n(:,2)=n(:,1);
n(1:piv,2)=[0:(1/(piv-1)):1]';
n(piv-2:64,2)=[1:-(1/(ipiv)):0]';

newmap=n;
