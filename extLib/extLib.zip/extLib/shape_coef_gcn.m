function [Mesh]= shape_coef_gcn(Mesh)
% (c) dmitry.aleynik@sams.ac.uk 2018.09.13;                               &
%  __o_O__�                                                               &
%  \_____/ ~~~~~~<@})))< ~ ~ ~~~~~ ~~~ SAMS KTP                           &
%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
%----------------------------------------------------------------------!
%!  This subrountine is used to calculate the coefficient for a linear  !
%!  function on the x-y plane, i.e.:                                    !
%!                     r(x,y;phai)=phai_c+cofa1*x+cofa2*y               !
%!     innc(i)=0    cells on the boundary                               !
%!     innc(i)=1    cells in the interior
% Usage: tic; [Mesh] = shape_coef_gcn(Mesh);toc;
%!----------------------------------------------------------------------!
%    clearvars  X1,X2,X3,Y1,Y2,Y3,DELT,AI1,AI2,AI3,BI1,BI2,BI3,CI1,CI2,CI3
%    clearvars DELTX,DELTY,TEMP1,ANG1,ANG2,B1,B2,ANGLE

%% ==================
    SPHERICAL = true;
    if max(abs(Mesh.x(:,2))) > 90,  SPHERICAL = false; end
    DEG2RAD = pi/180;  REARTH= 6371.0*1000; %m
    TPI       = DEG2RAD*REARTH ;%!TPI=pi*rearth/180.=3.14159265/180.0*6371.*1000.
    NV    = Mesh.tri ;
    NBE   = Mesh.nbe ;
    ISBCE = Mesh.isbce ; % ISBCE;
    N = Mesh.Nelems ;
    M = Mesh.Nverts ;
    XC(:,1)= Mesh.uvnode(:,1); % at x-coord of cell centroids
    YC(:,1)= Mesh.uvnode(:,2);
    VX(:,1)= Mesh.nodexy(:,1);
    VY(:,1)= Mesh.nodexy(:,2);

    nbve =Mesh.nbve;
    ntve =Mesh.ntve;
    isonb=Mesh.isonb;
    art  =Mesh.art;

    for I=1:N
        if(ISBCE(I) == 0),...
            Y1 = YC(NBE(I,1))-YC(I);
            Y2 = YC(NBE(I,2))-YC(I);
            Y3 = YC(NBE(I,3))-YC(I);
            if  (SPHERICAL),...
                    X1_DP = XC(I);
                Y1_DP = YC(I);
                X2_DP = XC(NBE(I,1));
                Y2_DP = YC(NBE(I,1));
                [SIDE]= arcx(X1_DP,Y1_DP,X2_DP,Y2_DP);
                X1=SIDE;

                X2_DP=XC(NBE(I,2));
                Y2_DP=YC(NBE(I,2));
                [SIDE]= arcx(X1_DP,Y1_DP,X2_DP,Y2_DP);
                X2=SIDE;

                X2_DP=XC(NBE(I,3));
                Y2_DP=YC(NBE(I,3));
                [SIDE]= arcx(X1_DP,Y1_DP,X2_DP,Y2_DP);
                X3=SIDE;

                Y1=TPI*Y1;
                Y2=TPI*Y2;
                Y3=TPI*Y3;
            else
                X1=XC(NBE(I,1))-XC(I);
                X2=XC(NBE(I,2))-XC(I);
                X3=XC(NBE(I,3))-XC(I);
            end % SPHERICAL

            X1=X1/1000.;
            X2=X2/1000.;
            X3=X3/1000.;
            Y1=Y1/1000.;
            Y2=Y2/1000.;
            Y3=Y3/1000.;

            delt=(X1*Y2-X2*Y1)^2+(X1*Y3-X3*Y1)^2+(X2*Y3-X3*Y2)^2;
            delt=delt*1000.;
            a1u(I,1)=(Y1+Y2+Y3)*(X1*Y1+X2*Y2+X3*Y3)- ... &
                (X1+X2+X3)*(Y1^2+Y2^2+Y3^2);
            a1u(I,1)=a1u(I,1)/delt;
            a1u(I,2)=(Y1^2+Y2^2+Y3^2)*X1-(X1*Y1+X2*Y2+X3*Y3)*Y1;
            a1u(I,2)=a1u(I,2)/delt;
            a1u(I,3)=(Y1^2+Y2^2+Y3^2)*X2-(X1*Y1+X2*Y2+X3*Y3)*Y2;
            a1u(I,3)=a1u(I,3)/delt;
            a1u(I,4)=(Y1^2+Y2^2+Y3^2)*X3-(X1*Y1+X2*Y2+X3*Y3)*Y3;
            a1u(I,4)=a1u(I,4)/delt;

            a2u(I,1)=(X1+X2+X3)*(X1*Y1+X2*Y2+X3*Y3)- ... &
                (Y1+Y2+Y3)*(X1^2+X2^2+X3^2);
            a2u(I,1)=a2u(I,1)/delt;
            a2u(I,2)=(X1^2+X2^2+X3^2)*Y1-(X1*Y1+X2*Y2+X3*Y3)*X1;
            a2u(I,2)=a2u(I,2)/delt;
            a2u(I,3)=(X1^2+X2^2+X3^2)*Y2-(X1*Y1+X2*Y2+X3*Y3)*X2;
            a2u(I,3)=a2u(I,3)/delt;
            a2u(I,4)=(X1^2+X2^2+X3^2)*Y3-(X1*Y1+X2*Y2+X3*Y3)*X3;
            a2u(I,4)=a2u(I,4)/delt;
        end % if

        if (SPHERICAL), ...
            X1=VX(NV(I,1));
            X2=VX(NV(I,2));
            X3=VX(NV(I,3));
            Y1=VY(NV(I,1));
            Y2=VY(NV(I,2));
            Y3=VY(NV(I,3));

            AI1=TPI*(Y2-Y3);
            AI2=TPI*(Y3-Y1);
            AI3=TPI*(Y1-Y2);
            %      CALL ARCX(X2,Y2,X3,Y3,side);
            [side]= arcx(X2,Y2,X3,Y3);
            BI1=side;
            %      CALL ARCX(X3,Y3,X1,Y1,side);
            [side]= arcx(X3,Y3,X1,Y1);
            BI2=side;
            %      CALL ARCX(X1,Y1,X2,Y2,side);
            [side]= arcx(X1,Y1,X2,Y2);
            BI3=side;
            X2_DP = XC(I);
            Y2_DP = YC(I);
            %      call ARCC(X1,Y1,X2_dp,Y2_dp,xxc1,yyc1);
            %      call ARCC(X2,Y2,X2_dp,Y2_dp,xxc2,yyc2);
            %      call ARCC(X3,Y3,X2_dp,Y2_dp,xxc3,yyc3);
            [XXC1,YYC1 ]= arcc(X1,Y1,X2_DP,Y2_DP);
            [XXC2,YYC2 ]= arcc(X2,Y2,X2_DP,Y2_DP);
            [XXC3,YYC3 ]= arcc(X3,Y3,X2_DP,Y2_DP);

            XTMP1  = X1*TPI-XC(I)*TPI;
            XTMP2  = X2*TPI-XC(I)*TPI;
            XTMP3  = X3*TPI-XC(I)*TPI;
            XTMP11 = X1-XC(I);
            XTMP21 = X2-XC(I);
            XTMP31 = X3-XC(I);

            if (XTMP11 >  180.0),...
                XTMP1 = -360.0*TPI+XTMP1 ;
            elseif (XTMP11 < -180.0),...
                XTMP1 =  360.0*TPI+XTMP1 ;
            end
            if (XTMP21 >  180.0),...
                XTMP2 = -360.0*TPI+XTMP2 ;
            elseif(XTMP21 < -180.0),...
                XTMP2 =  360.0*TPI+XTMP2;
            end

            if(XTMP31 >  180.0),...
                XTMP3 = -360.0*TPI+XTMP3 ;
            elseif(XTMP31 < -180.0),...
                XTMP3 =  360.0*TPI+XTMP3 ;
            end

            CI1=XTMP2*TPI*(Y3-YC(I))*cos(DEG2RAD*YYC2)-... &
                XTMP3*TPI*(Y2-YC(I))*cos(DEG2RAD*YYC3);

            CI2=XTMP3*TPI*(Y1-YC(I))*cos(DEG2RAD*YYC3)- ... &
                XTMP1*TPI*(Y3-YC(I))*cos(DEG2RAD*YYC1);

            CI3=XTMP1*TPI*(Y2-YC(I))*cos(DEG2RAD*YYC1)-...&
                XTMP2*TPI*(Y1-YC(I))*cos(DEG2RAD*YYC2);

        else
            X1=VX(NV(I,1))-XC(I);
            X2=VX(NV(I,2))-XC(I);
            X3=VX(NV(I,3))-XC(I);
            Y1=VY(NV(I,1))-YC(I);
            Y2=VY(NV(I,2))-YC(I);
            Y3=VY(NV(I,3))-YC(I);

            AI1=Y2-Y3;
            AI2=Y3-Y1;
            AI3=Y1-Y2;
            BI1=X3-X2;
            BI2=X1-X3;
            BI3=X2-X1;
            CI1=X2*Y3-X3*Y2;
            CI2=X3*Y1-X1*Y3;
            CI3=X1*Y2-X2*Y1;
        end %if---------- spherical

        aw0(I,1)=-CI1/2./art(I);
        aw0(I,2)=-CI2/2./art(I);
        aw0(I,3)=-CI3/2./art(I);
        awx(I,1)=-AI1/2./art(I);
        awx(I,2)=-AI2/2./art(I);
        awx(I,3)=-AI3/2./art(I);
        awy(I,1)=-BI1/2./art(I);
        awy(I,2)=-BI2/2./art(I);
        awy(I,3)=-BI3/2./art(I);
    end % do I

    % !--------boundary cells------------------------------------------------!
    for i=1:N,...
        if (ISBCE(i) > 1),...
            for j=1:4,...
                a1u(i,j)=0.0;
            a2u(i,j)=0.0;
            end
        elseif (ISBCE(i) == 1)
            for j=1:3,...
                if (NBE(i,j) == 0), jj=j; end
            end
            j1=jj+1-fix((jj+1)/4)*3;
            j2=jj+2-fix((jj+2)/4)*3;

            X1=VX(NV(i,j1))-XC(i);
            X2=VX(NV(i,j2))-XC(i);
            Y1=VY(NV(i,j1))-YC(i);
            Y2=VY(NV(i,j2))-YC(i);

            if (SPHERICAL),...
                    TY1=0.5*(VY(NV(i,j1))+YC(i));

                TY2=0.5*(VY(NV(i,j2))+YC(i));

                XTMP1  = VX(NV(i,j1))*TPI-XC(i)*TPI;
                XTMP2  = VX(NV(i,j2))*TPI-XC(i)*TPI;
                XTMP11 = VX(NV(i,j1))-XC(i);
                XTMP21 = VX(NV(i,j2))-XC(i);
                if (XTMP11 >  180.0)
                    XTMP1 = -360.0*TPI+XTMP1;
                elseif (XTMP11 < -180.0)
                    XTMP1 =  360.0*TPI+XTMP1;
                end

                if (XTMP21 >  180.0)
                    XTMP2 = -360.0*TPI+XTMP2;
                elseif (XTMP21 < -180.0)
                    XTMP2 =  360.0*TPI+XTMP2;
                end

                X1=XTMP1*cos(DEG2RAD*TY1);
                X2=XTMP2*cos(DEG2RAD*TY2);
                Y1=TPI*Y1;
                Y2=TPI*Y2;
            end

            delt=X1*Y2-X2*Y1;
            b1=(Y2-Y1)/delt;
            b2=(X1-X2)/delt;
            DELTX=VX(NV(i,j1))-VX(NV(i,j2));
            DELTY=VY(NV(i,j1))-VY(NV(i,j2));

            if (SPHERICAL)
                X1_DP=VX(NV(i,j1));
                Y1_DP=VY(NV(i,j1));
                X2_DP=VX(NV(i,j2));
                Y2_DP=VY(NV(i,j2));
                %          call ARCX(X2_dp,Y2_dp,X1_dp,Y1_dp,side)
                [ SIDE ]= arcx(X2_DP,Y2_DP,X1_DP,Y1_DP);

                DELTX=SIDE;
                DELTY=TPI*DELTY;
            end
            ALPHA(i)=atan2(DELTY,DELTX);
            ALPHA(i)=ALPHA(i)-3.1415926/2.0;
            %   if   % --------DA
            % TPA added condition here to prevent calculation for problem
            % elements (which have two land sides)
            if (NBE(i,j1) > 0 && NBE(i,j2) > 0)
                X1=XC(NBE(i,j1))-XC(i);
                Y1=YC(NBE(i,j1))-YC(i);
                X2=XC(NBE(i,j2))-XC(i);
                Y2=YC(NBE(i,j2))-YC(i);

                %     if 0
                %       if(NBE(i,j1) == 0)
                %        X1=0;
                %        Y1=0;
                %        else
                %        X1=XC(NBE(i,j1))-XC(i);
                %        Y1=YC(NBE(i,j1))-YC(i);
                %       end
                %       if(NBE(i,j2) == 0)
                %        X2=0;
                %        Y2=0;
                %       else
                %        X2=XC(NBE(i,j2))-XC(i);
                %        Y2=YC(NBE(i,j2))-YC(i);
                %       end
                %     end % da

                if (SPHERICAL)
                    TY1=0.5*(YC(NBE(i,j1))+YC(i));

                    TY2=0.5*(YC(NBE(i,j2))+YC(i));

                    XTMP1  = XC(NBE(i,j1))*TPI-XC(i)*TPI;
                    XTMP2  = XC(NBE(i,j2))*TPI-XC(i)*TPI;
                    XTMP11 = XC(NBE(i,j1))-XC(i);
                    XTMP21 = XC(NBE(i,j2))-XC(i);
                    if (XTMP11 >  180.0)
                        XTMP1 = -360.0*TPI+XTMP1;
                    elseif (XTMP11 < -180.0)
                        XTMP1 =  360.0*TPI+XTMP1 ;
                    end
                    if (XTMP21 >  180.0)
                        XTMP2 = -360.0*TPI+XTMP2;
                    elseif (XTMP21 < -180.0)
                        XTMP2 =  360.0*TPI+XTMP2;
                    end

                    X1=XTMP1*cos(DEG2RAD*TY1);
                    X2=XTMP2*cos(DEG2RAD*TY2);
                    Y1=TPI*Y1;
                    Y2=TPI*Y2;
                end
            end

            temp1=X1*Y2-X2*Y1;

            if (abs(temp1) < 1.e-6)
                disp( ['shape_f of solid b. c. temp1=0' ]);
                disp( [ 'i,jj,j1,j2,X1,X2,Y1,Y2' ]);
                disp( [ num2str( [i,jj,j1,j2,X1,X2,Y1,Y2] ) ';' ]);
                disp( [ 'X1*Y2==',num2str(X1*Y2) ] ) ;
                disp( [ 'X2*Y1==',num2str(X2*Y1) ] ) ;
                %stop
            end

            a1u(i,1)=0.0;
            a1u(i,jj+1)=0.0;
            a1u(i,j1+1)=0.0;
            a1u(i,j2+1)=0.0;

            a2u(i,1)=0.0;
            a2u(i,jj+1)=0.0;
            a2u(i,j1+1)=0.0;
            a2u(i,j2+1)=0.0;
        end %if
    end %do i

%     ang1=359.9/180.0*3.1415926;
%     ang2=-0.1/180.0*3.1415926 ;
%
%     for i=1:M,...
%         if((isonb(i) == 1)  && (ntve(i) > 2))
%         angle=ALPHA(nbve(i,ntve(i))) - ALPHA(nbve(i,1));
%         if(angle > ang1)
%             angle=100000.0;
%         elseif(angle > 3.1415926)
%             angle=angle-2.0*3.1415926;
%         elseif(angle < -3.1415926)
%             angle=angle+2.0*3.1415926;
%         elseif(angle < ang2)
%             angle=100000.0;
%         end %if
%         for j=2:ntve(i)-1
%             ii=nbve(i,j);
%             if (ISBCE(ii) ~= 1)
%                 ALPHA(ii)=ALPHA(nbve(i,1)) + ... &
%                     angle/(ntve(i)-1)*(j-1);
%             end %if
%         end% do;
%         end %if
%     end %do i

    Mesh.a1u= a1u;
    Mesh.a2u= a2u;
    Mesh.aw0= aw0;
    Mesh.awx= awx;
    Mesh.awy= awy;
    % Mesh.alha=alpha;
    %    return

end % subroutine shape_coef_gcn
