function [CVM] = isonb_m(CVM,Mesh)
 %global Mesh
 N=Mesh.Nelems;
 M=Mesh.Nverts;
 NV  = Mesh.trinodes;
 NBE = CVM.NBE;    %  NBE  % "elements surrounding each element" ;NBE!!INDICES OF ELMNT NEIGHBORS
ISBCE=zeros(1,N);
ISONB=zeros(1,M);
  ART=zeros(N,1);
for I=1:N ,...
     if(min(min(NBE(I,1),NBE(I,2)), NBE(I,3))==0) ,...  % !!ELEMENT ON BOUNDARY
        ISBCE(I) = 1;
        if(NBE(I,1) == 0),...
           ISONB(NV(I,2)) = 1 ; ISONB(NV(I,3)) = 1;
        end
        if(NBE(I,2) ==0) ,...
           ISONB(NV(I,1)) = 1 ; ISONB(NV(I,3)) = 1;
        end
        if(NBE(I,3) ==0) ,...
           ISONB(NV(I,1)) = 1 ; ISONB(NV(I,2)) = 1;
        end
      end
end
CVM.isonb=ISONB';
CVM.isbce=ISBCE';
% ART == area of element (triangle)

   VX = Mesh.nodexy(:,1);
   VY = Mesh.nodexy(:,2);
    for I=1:N,...
    ART(I,1) = (VX(NV(I,2)) - VX(NV(I,1))) * (VY(NV(I,3)) - VY(NV(I,1))) - ...
               (VX(NV(I,3)) - VX(NV(I,1))) * (VY(NV(I,2)) - VY(NV(I,1)));
    end
   ART    = abs(0.5.*ART);
 % ART(0) = ART(1) ;
   CVM.art=ART;
end