 function [Mesh] = cell_area(Mesh, nmfcell,I_MFCELL_N)
%% dmitry.aleynik@sams.ac.uk (c)2011.10.10
% see \FVCOM_code_new\cell_area.F & mod_meanflow.F  & tge.F
%!-COMPUTE CONTROL VOLUME ART1: CV FOR FLUXES OF NODAL BASED VALUES--! 24 sec
 NV = Mesh.tri ; %nv=NV;
% NBE =Mesh.nbe ;
  N=Mesh.Nelems;
  M=Mesh.Nverts;

    H = Mesh.x(:,3);            % =D
   VX = Mesh.x(:,1);
   VY = Mesh.x(:,2);
%% from    setup_metrics ==>
geog=Mesh.geog;
   Nelems=N;
   Nverts=M;
   nbet = zeros(Nelems,3);
   cells = zeros(Nverts,10);
   cellcnt = zeros(Nverts,1);
   nbe = zeros(Nelems,3);
    tri=Mesh.tri;
   for i = 1:Nelems
     n1 = tri(i,1) ; cellcnt(n1) = cellcnt(n1) + 1;
     n2 = tri(i,2) ; cellcnt(n2) = cellcnt(n2) + 1;
     n3 = tri(i,3) ; cellcnt(n3) = cellcnt(n3) + 1;
     cells(tri(i,1),cellcnt(n1)) = i;
     cells(tri(i,2),cellcnt(n2)) = i;
     cells(tri(i,3),cellcnt(n3)) = i;
   end;

   if(max(cellcnt) > 12)
     error('increase cells array')
   end;

   for i = 1:Nelems
     n1 = tri(i,1); n2 = tri(i,2); n3 = tri(i,3);

     for j1 = 1:cellcnt(n1)
     for j2 = 1:cellcnt(n2)
       if((cells(n1,j1) == cells(n2,j2)) && cells(n1,j1) ~= i); nbe(i,3) = cells(n1,j1); end;
     end;
     end;
     for j2 = 1:cellcnt(n2)
     for j3 = 1:cellcnt(n3)
       if((cells(n2,j2) == cells(n3,j3)) && cells(n2,j2) ~= i); nbe(i,1) = cells(n2,j2); end;
     end;
     end;
     for j1 = 1:cellcnt(n1)
     for j3 = 1:cellcnt(n3)
       if((cells(n1,j1) == cells(n3,j3)) && cells(n1,j1) ~= i); nbe(i,2) = cells(n3,j3); end;
     end;
     end;
   end;

  % save junk geog Nverts Nelems tri nbe
%    fprintf('done nbe stuff\n')

   icnt = 0;
   bnodes = zeros(Nverts,1);
   bcells = zeros(Nelems,1);
   check = floor(Nelems/100);
   for i=1:Nelems
      n1 = tri(i,1); n2 = tri(i,2); n3 = tri(i,3);
      if(nbe(i,1) == 0)
        icnt = icnt + 1;
        bnodes(n2) = 1; bnodes(n3) = 1; bcells(i) = 1;
        bndryx(icnt,1:2) = [geog(n2,1),geog(n3,1)];
        bndryy(icnt,1:2) = [geog(n2,2),geog(n3,2)];
      elseif(nbe(i,2) == 0)
        icnt = icnt + 1;
        bnodes(n3) = 1; bnodes(n1) = 1; bcells(i) = 1;
        bndryx(icnt,1:2) = [geog(n1,1),geog(n3,1)];
        bndryy(icnt,1:2) = [geog(n1,2),geog(n3,2)];
      elseif(nbe(i,3) == 0)
        icnt = icnt + 1;
        bnodes(n1) = 1; bnodes(n2) = 1; bcells(i) = 1;
        bndryx(icnt,1:2) = [geog(n1,1),geog(n2,1)];
        bndryy(icnt,1:2) = [geog(n1,2),geog(n2,2)];
      end;
    %   if(mod(i,check)==0); fprintf('bnodes: completed %f percent \n',100*i/Nelems); end;
   end;
      if(mod(i,check)==0); fprintf('bnodes: completed %f percent \n',100*i/Nelems); end;
     nbndry = icnt;
% determine edges
Nedges = Nelems*3;
edge = zeros(Nedges,2);
icnt = 1;
for i=1:Nelems
  edge(icnt  ,1:2) = tri(i,1:2);
  edge(icnt+1,1:2) = tri(i,2:3);
  edge(icnt+2,1:2) = tri(i,[3,1]);
  icnt = icnt + 3;
end;

% determine nodes surrounding nodes (no specific order)
ntsn = zeros(Nverts,1);
nbsn = zeros(Nverts,12);

for i=1:Nedges
  i1 = edge(i,1);
  i2 = edge(i,2);
  [lmin,loc] = min(abs(nbsn(i1,:)-i2));
  if(lmin ~= 0);
    ntsn(i1) = ntsn(i1)+1;
    nbsn(i1,ntsn(i1)) = i2;
  end;
  [lmin,loc] = min(abs(nbsn(i2,:)-i1));
  if(lmin ~= 0);
    ntsn(i2) = ntsn(i2)+1;
    nbsn(i2,ntsn(i2)) = i1;
  end;
end;
     Mesh.bnodes=bnodes;
     Mesh.bndryx=bndryx;
     Mesh.bndryy=bndryx;
     Mesh.nbe=nbe;
          NBE=nbe;
     Mesh.NBE=nbe; try CVM.NBE=nbe;end
     Mesh.ntsn=ntsn;
     Mesh.nbsn=nbsn;
     Mesh.edge=edge;
 fprintf('done nbe stuff\n');

%% from    setup_metrics ==< end

%% ==================
 %% get few arrays:
 ISBCE=zeros(1,N);
 ISONB=zeros(1,M);
   ART=zeros(N,1);

for I=1:N ,...
     if(min(min(NBE(I,1),NBE(I,2)), NBE(I,3))==0) ,...  % !!ELEMENT ON BOUNDARY
        ISBCE(I) = 1;
        if(NBE(I,1) == 0),...
           ISONB(NV(I,2)) = 1 ; ISONB(NV(I,3)) = 1;
        end
        if(NBE(I,2) ==0) ,...
           ISONB(NV(I,1)) = 1 ; ISONB(NV(I,3)) = 1;
        end
        if(NBE(I,3) ==0) ,...
           ISONB(NV(I,1)) = 1 ; ISONB(NV(I,2)) = 1;
        end
      end
end;

  for I=1:N,...
  ART(I,1)=(VX(NV(I,2)) - VX(NV(I,1))) * (VY(NV(I,3)) - VY(NV(I,1))) - ...
           (VX(NV(I,3)) - VX(NV(I,1))) * (VY(NV(I,2)) - VY(NV(I,1)));
  end
  ART    = abs(0.5.*ART);
%% ===============
 ISONB=ISONB';
 ISBCE=ISBCE';
%do updates to Mesh :
 Mesh.ISONB=ISONB;
 Mesh.ISBCE=ISBCE;
 Mesh.ART  =ART;

%%  ==========================
                  % get from Mesh, MX_NBR_ELEM =9
                     MX_NBR_ELEM = 0;
  for I=1:M,
     NCNT = 0;
     for J=1:N,...
       if( (NV(J,1)-I)*(NV(J,2)-I)*(NV(J,3)-I) == 0) ,...
         NCNT = NCNT + 1;
       end
     end
     MX_NBR_ELEM = max(MX_NBR_ELEM,NCNT);
  end;

  NBVE=zeros(M,MX_NBR_ELEM);
  NBVT=zeros(M,MX_NBR_ELEM);
  NBSN=zeros(M,MX_NBR_ELEM+3);

  NTVE=zeros(M,1);

   for I=1:M,...
     NCNT=0;
     for J=1:N,...
         if ( (NV(J,1)-I)*(NV(J,2)-I)*(NV(J,3)-I) == 0),...
         NCNT = NCNT+1;
         NBVE(I,NCNT)=J;
         if((NV(J,1)-I) == 0), NBVT(I,NCNT)=1; end
         if((NV(J,2)-I) == 0), NBVT(I,NCNT)=2; end
         if((NV(J,3)-I) == 0), NBVT(I,NCNT)=3; end
        end
     end;
     NTVE(I)=NCNT;
   end;

% !--Reorder Order Elements Surrounding a Node to Go in a Cyclical Procession----!
% !--Determine NTSN  = Number of Nodes Surrounding a Node (+1)-------------------!
% !--Determine NBSN  = Node Numbers of Nodes Surrounding a Node------------------!
!
   NB_TMP=zeros(M,MX_NBR_ELEM+1);
    NTSN=zeros(M,1);
 for I=1:M,...
     if(ISONB(I) == 0) ,...
       NB_TMP(1,1)=NBVE(I,1);
       NB_TMP(1,2)=NBVT(I,1);
      for J=2:NTVE(I)+1,...
         II=NB_TMP(J-1,1);
         JJ=NB_TMP(J-1,2);
          NB_TMP(J,1)=NBE(II,JJ+1-fix((JJ+1)/4)*3);
         JJ=NB_TMP(J,1);
         if((NV(JJ,1)-I) == 0), NB_TMP(J,2)=1;end
         if((NV(JJ,2)-I) == 0), NB_TMP(J,2)=2;end
         if((NV(JJ,3)-I) == 0), NB_TMP(J,2)=3;end
      end;

       for J=2:NTVE(I)+1,...
         NBVE(I,J)=NB_TMP(J,1);
       end;

       for J=2:NTVE(I)+1,...
         NBVT(I,J)=NB_TMP(J,2);
       end;

       NTMP=NTVE(I)+1;
       if (NBVE(I,1) ~= NBVE(I,NTMP)) ,...
   disp([' MYID,ngid(I),NTMP=', num2str(NTMP),',NBVE(I,NTMP)=' num2str(NBVE(I,NTMP)) ' NOT CORRECT!!  L223'] );
   disp([' "NBVE(I,:)=", EGID(' num2str(NBVE(I,:) ) '); I='  num2str(I)     ]);
%           stop; %exit %CALL PSTOP
       end

       if (NBVT(I,1) ~= NBVT(I,NTMP)) ,...
          disp(['  ngid(I), NBVT(I) NOT CORRECT!!  L229' ]    );
          disp(['  "NBVT(I,:)=",' num2str(NBVT(I,:)) ', I=' num2str(I) ]);
%            stop;% exit %CALL PSTOP
       end

       NTSN(I)=NTVE(I);

       for  J=1:NTSN(I),...
         II=NBVE(I,J);
         JJ=NBVT(I,J);
         NBSN(I,J)=NV(II,JJ+1-fix((JJ+1)/4)*3);
       end;

       NTSN(I)=NTSN(I)+1;
       NBSN(I,NTSN(I))=NBSN(I,1);

     else
           JJB=0;

      for J=1:NTVE(I),...
         JJ=NBVT(I,J);
                            JJJ=JJ+2-fix((JJ+2)/4)*3;
         if (NBE(NBVE(I,J), JJJ) == 0),...
           JJB=JJB+1;
           NB_TMP(JJB,1)=NBVE(I,J);
           NB_TMP(JJB,2)=NBVT(I,J);
         end
      end;

       if (JJB ~= 1),...
         disp(['ERROR IN ISONB !,I,J='  num2str(I) ',' num2str(J) ' L259' ]);
         disp('"ERROR IN TGE DETERMINING ISONB"');
%          stop
       end

       for J=2:NTVE(I),...
         II=NB_TMP(J-1,1);
         JJ=NB_TMP(J-1,2);
         NB_TMP(J,1)=NBE(II,JJ+1-fix((JJ+1)/4)*3);
         JJ=NB_TMP(J,1);
         if((NV(JJ,1)-I) == 0), NB_TMP(J,2)=1;end
         if((NV(JJ,2)-I) == 0), NB_TMP(J,2)=2;end
         if((NV(JJ,3)-I) == 0), NB_TMP(J,2)=3;end
       end;

       for J=1:NTVE(I),...
         NBVE(I,J)=NB_TMP(J,1);
         NBVT(I,J)=NB_TMP(J,2);
       end

       NBVE(I,NTVE(I)+1)=0;
       NTSN(I)=NTVE(I)+1  ;
       NBSN(I,1)=I        ;

       for J=1:NTSN(I)-1,...
         II=NBVE(I,J);
         JJ=NBVT(I,J);
         NBSN(I,J+1)=NV(II,JJ+1-fix((JJ+1)/4)*3);
       end;

       J=NTSN(I);
       II=NBVE(I,J-1);
       JJ=NBVT(I,J-1);
       NBSN(I,J+1)=NV(II,JJ+2-fix((JJ+2)/4)*3);
       NTSN(I)=NTSN(I)+2;
       NBSN(I,NTSN(I))=I;
     end; %if_(isonb==0)_end
 end;     %
%=============

  Mesh.NBVE=NBVE;
  Mesh.NBVT=NBVT;
  Mesh.NTVE=NTVE;
  Mesh.NTSN=NTSN;
  Mesh.NBSN=NBSN;
%% ======== ======= ART1 ?
   ART1=zeros(M,1);
   ART2=zeros(M,1);
      MAX_NBRE = max(NTVE)+1;
   XX=zeros(2*MAX_NBRE+1) ;
   YY=zeros(2*MAX_NBRE+1) ;
    XC=zeros(N,1);  YC=zeros(N,1);
      for I = 1:N,...
      XC(I) = (VX(NV(I,1))+VX(NV(I,2))+VX(NV(I,3)))/3;
      YC(I) = (VY(NV(I,1))+VY(NV(I,2))+VY(NV(I,3)))/3;
      end
   Mesh.XC=XC;
   Mesh.YC=YC;
%%  plot(Mesh.bndryx,Mesh.bndryy,'.');

for I=1:M,...
    if(ISONB(I) == 0) ,...
       for J=1:NTVE(I),...
         II=NBVE(I,J);
         J1=NBVT(I,J);
         J2=J1+1-fix((J1+1)/4)*3;
         XX(2*J-1)=(VX(NV(II,J1))+VX(NV(II,J2)))*0.5-VX(I);
         YY(2*J-1)=(VY(NV(II,J1))+VY(NV(II,J2)))*0.5-VY(I);
         XX(2*J)=XC(II)-VX(I);
         YY(2*J)=YC(II)-VY(I);
       end;

       XX(2*NTVE(I)+1)=XX(1);
       YY(2*NTVE(I)+1)=YY(1);

       for J=1:2*NTVE(I),...
          ART1(I)=ART1(I)+0.5*(XX(J+1)*YY(J)-XX(J)*YY(J+1));
       end;
       ART1(I)=abs(ART1(I));

    else

       for J=1:NTVE(I),...
         II=NBVE(I,J);
         J1=NBVT(I,J);
         J2=J1+1-fix((J1+1)/4)*3;
         XX(2*J-1)=(VX(NV(II,J1))+VX(NV(II,J2)))*0.5-VX(I);
         YY(2*J-1)=(VY(NV(II,J1))+VY(NV(II,J2)))*0.5-VY(I);
         XX(2*J)=XC(II)-VX(I);
         YY(2*J)=YC(II)-VY(I);
       end;

       J=NTVE(I)+1;
       II=NBVE(I,J-1);
       J1=NBVT(I,NTVE(I));
       J2=J1+2-fix((J1+2)/4)*3;

       XX(2*J-1)=(VX(NV(II,J1))+VX(NV(II,J2)))*0.5-VX(I);
       YY(2*J-1)=(VY(NV(II,J1))+VY(NV(II,J2)))*0.5-VY(I);

       XX(2*J)=VX(I)-VX(I);
       YY(2*J)=VY(I)-VY(I);

       XX(2*J+1)=XX(1);
       YY(2*J+1)=YY(1);

     for J=1:2*NTVE(I)+2,...
        ART1(I)=ART1(I)+0.5*(XX(J+1)*YY(J)-XX(J)*YY(J+1));
     end;
       ART1(I)=abs(ART1(I));
    end ; %isonb
end;

  for I=1:M,...
     ART2(I) = sum(ART(NBVE(I,1:NTVE(I))));
  end
 Mesh.ART1 =ART1;
 Mesh.ART2 =ART2;
% ----------------------sides:
ISET=zeros(N,3);  TEMP=zeros((N)*3,2); TEMP2=zeros((N)*3,2);
          NE=0;
  for I=1:N,...
     for J=1:3,...
       if (ISET(I,J) == 0),...
         NE   = NE + 1;
         INEY = NBE(I,J);
         ISET(I,J) = 1;

         for JN=1:3,...
                 if INEY > 0,...                                %!da ???
           if(I == NBE(INEY,JN)) , ISET(INEY,JN) = 1; end
                 end
         end;

         TEMP(NE,1) = I ; TEMP(NE,2) = INEY;
         TEMP2(NE,1) = NV(I,J+1-fix((J+1)/4)*3);
         TEMP2(NE,2) = NV(I,J+2-fix((J+2)/4)*3);
       end
     end;
  end;
% ================================
   IEC(:,1) = TEMP(1:NE,1);
   IEC(:,2) = TEMP(1:NE,2);
   IENODE(:,1) = TEMP2(1:NE,1);
   IENODE(:,2) = TEMP2(1:NE,2);

  Mesh.NE     =NE;     %number of unique element edges
  Mesh.IENODE =IENODE; %the identification number of two end points of an edge
  Mesh.IEC    =IEC;    %counting number identifying two connected cells
                     clear TEMP TEMP2

 DLTXC=zeros(NE,1);  DLTYC=zeros(NE,1);  XIJC =zeros(NE,1);
 YIJC =zeros(NE,1); DLTXYC=zeros(NE,1);  SITAC =zeros(NE,1);

 for I=1:NE,...
     DLTXC(I) =  VX(IENODE(I,2))-VX(IENODE(I,1));
     DLTYC(I) =  VY(IENODE(I,2))-VY(IENODE(I,1));
     XIJC(I)  = (VX(IENODE(I,1))+VX(IENODE(I,2)))/2.0;
     YIJC(I)  = (VY(IENODE(I,1))+VY(IENODE(I,2)))/2.0;
     DLTXYC(I)= sqrt(DLTXC(I)^2+DLTYC(I)^2);
     SITAC(I) = atan2(DLTYC(I),DLTXC(I));
end;
  Mesh.DLTXC =DLTXC;% vx(ienode(i,2))-vx(idnode(i,1))
  Mesh.DLTYC =DLTYC;% vy(ienode(i,2))-vy(idnode(i,1))
  Mesh.XIJC  =XIJC ;% the x-coordinate location of the middle points
  Mesh.YIJC  =YIJC ;
  Mesh.DLTXYC=DLTXYC;% length of the edge
  Mesh.SITAC =SITAC ;%  arctg(dltyc,dltxc)

%% =======================
   RDISMF=zeros(nmfcell,2);
   ANGLEMF=zeros(nmfcell,1);
   MFAREA=zeros(nmfcell,1);
   NODE_MFCELL=zeros(nmfcell,2);
for I=1:nmfcell,...
       II=I_MFCELL_N(I);
         ITMP=0;
       for J=1:3,...
         if (NBE(II,J) == 0 && ISONB(NV(II,J)) ~= 2) ,...
           JTMP=J;
           ITMP=ITMP+1;
         end
       end;

       if(ITMP ~= 1),...
        disp(' NO OPEN BOUNDARY OR MORE THAN ONE OPEN BOUNDARY, L444');
        disp([' IN NO. ',num2str(I),' MEAN FLOW CELL']);
          %exit ; %   CALL PSTOP
%           stop
       end
%
       J1=JTMP+1-fix( (JTMP+1)/4)*3; % int
       J2=JTMP+2-fix( (JTMP+2)/4)*3;

       I1=NV(II,J1);
       I2=NV(II,J2);

       NODE_MFCELL(I,1)=I1;
       NODE_MFCELL(I,2)=I2;

       HTMP=0.5*(H(I1)+H(I2)) ;   % ! may be a problem here, should be replaced dy D

       DY12=VY(I1)-VY(I2)  ;
       DX12=VX(I1)-VX(I2);

       ATMP1=atan2(DY12,DX12);
       MFAREA(I,1)=sqrt( DX12^2 + DY12^2 )*HTMP  ;  %! for spherical coordinates is Phthagolean Theorem still valid?
       ANGLEMF(I,1)=ATMP1 + 3.1415927/2.0;         % pi/2;%
       RDISMF(I,1)=ART1(I1)/(ART1(I1)+ART1(I2));
       RDISMF(I,2)=ART1(I2)/(ART1(I1)+ART1(I2));
end;
     Mesh.RDISMF =RDISMF;
     Mesh.ANGLEMF=ANGLEMF;
     Mesh.MFAREA =MFAREA;

% end