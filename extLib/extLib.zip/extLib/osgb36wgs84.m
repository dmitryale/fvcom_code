% osgb36wgs84.m        ; % (c) dmitry.aleynik@sams.ac.uk 
% Date:    07.01.2011   ; matlab script; !da updated 2018.04.11
% Project: Asimuth EU-FP7: algae bloom monitoring
% based  : on java code Chris Veness 2005-2010 :
% http://www.movable-type.co.uk/scripts/latlong-convert-coords.html

function [lon, lat] = osgb36wgs84(rlon,rlat,key)
%key == 0: o -> w 
%key ~= 0: w -> o 
% ellipsoides partameters       e:
        e.WGS84.a    = 6378137         ; 
        e.WGS84.b    = 6356752.3142    ; 
        e.WGS84.f    = 1/298.257223563 ;
        
        e.Airy1830.a = 6377563.396   ; 
        e.Airy1830.b = 6356256.910   ; 
        e.Airy1830.f = 1/299.3249646 ;

% helmert transform parameters h:
  h.WGS84toOSGB36.tx = -446.448 ; h.WGS84toOSGB36.ty = 125.157; h.WGS84toOSGB36.tz = -542.060 ;% m
  h.WGS84toOSGB36.rx = -0.1502  ; h.WGS84toOSGB36.ry = -0.2470; h.WGS84toOSGB36.rz = -0.8421  ;% sec
  h.WGS84toOSGB36.s  = 20.4894  ; % ppm
  
  h.OSGB36toWGS84.tx = 446.448  ; h.OSGB36toWGS84.ty = -125.157; h.OSGB36toWGS84.tz = 542.060 ;
  h.OSGB36toWGS84.rx = 0.1502   ; h.OSGB36toWGS84.ry =   0.2470; h.OSGB36toWGS84.rz =  0.8421 ;
  h.OSGB36toWGS84.s = -20.4894  ;

         p1.lon    =rlon;
         p1.lat    =rlat;        
         p1.height =0   ;
 if (key==0 ),...         
% convertOSGB36toWGS84(p1);
          p2 = convert(p1, e.Airy1830, h.OSGB36toWGS84, e.WGS84);
 else          
% convertWGS84toOSGB36(p1)
          p2 = convert(p1, e.WGS84, h.WGS84toOSGB36, e.Airy1830);
 end
          lon=p2.lon;
          lat=p2.lat;
end

% end

 function p2 = convert(p1, e1, t, e2) 
  % -- convert polar to cartesian coordinates (using ellipse 1)
  % p1.lon =rlon;  p1.lat =rlat;
  p1.lat = p1.lat*pi/180; 
  p1.lon = p1.lon*pi/180; 

  a = e1.a; b = e1.b ;

  sinPhi    = sin(p1.lat); 
  cosPhi    = cos(p1.lat);
  sinLambda = sin(p1.lon); 
  cosLambda = cos(p1.lon);
          H = p1.height;

   eSq = (a*a - b*b) / (a*a);
   nu = a ./ sqrt(1 - eSq*sinPhi.*sinPhi);

   x1 = (nu+H) .* cosPhi .* cosLambda;
   y1 = (nu+H) .* cosPhi .* sinLambda;
   z1 = ((1-eSq)*nu + H) .* sinPhi;


  % -- apply helmert transform using appropriate params
  
   tx = t.tx; ty = t.ty; tz = t.tz;
   rx = t.rx/3600 * pi/180;  % normalise seconds to radians
   ry = t.ry/3600 * pi/180;
   rz = t.rz/3600 * pi/180;
   s1 = t.s/1e6 + 1;              % normalise ppm to (s+1)

  % apply transform
   x2 = tx + x1*s1 - y1*rz + z1*ry;
   y2 = ty + x1*rz + y1*s1 - z1*rx;
   z2 = tz - x1*ry + y1*rx + z1*s1;


  % -- convert cartesian to polar coordinates (using ellipse 2)

  a = e2.a; b = e2.b;
   precision = 4 / a;  % results accurate to around 4 metres

  eSq   = (a*a - b*b) / (a*a);
   p    = sqrt(x2.*x2 + y2.*y2);
   phi  = atan2(z2, p*(1-eSq));
   phiP = 2*pi;
   
  while (abs(phi-phiP) > precision) ,...
    nu = a ./ sqrt(1 - eSq*sin(phi).*sin(phi));
    phiP = phi;
    phi = atan2(z2 + eSq*nu.*sin(phi), p);
  end
  
   lambda = atan2(y2, x2);
        H = p./cos(phi) - nu;
        
  p2.lat    = phi*180/pi;
  p2.lon    = lambda*180/pi;
 end
 
 %return new LatLon(phi.toDeg(), lambda.toDeg(), H);
 
