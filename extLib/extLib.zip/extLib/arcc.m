function[XXC,YYC ]= arcc(XX1,YY1,XX2,YY2)
% call from SHAPE_COEF_GCN
% (c) dmitry.aleynik@sams.ac.uk 2018.09.13;                               & 
%  __o_O__�                                                               &
%  \_____/ ~~~~~~<@})))< ~ ~ ~~~~~ ~~~ SAMS KTP                           &
%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
% SUBROUTINE ARCC_DBL(XX1,YY1,XX2,YY2,XXC,YYC)
 DEG2RAD=pi/180;  
 REARTH= 6371.0*1000; %m
%  TPI       = DEG2RAD*REARTH ; %!TPI=pi*rearth/180.=3.14159265/180.0*6371.*1000.
 
    X1=XX1*DEG2RAD;
    Y1=YY1*DEG2RAD;

    X2=XX2*DEG2RAD;
    Y2=YY2*DEG2RAD;

    XXC=cos(Y1)*sin(X1)+cos(Y2)*sin(X2);
    XXC=atan2(XXC,(cos(Y1)*cos(X1)+cos(Y2)*cos(X2)));
    XXC=XXC/DEG2RAD;

    if (XXC < 0.0)
        XXC=360.0+XXC; 
    end

    YYC=cos(Y1)*cos(Y1)+cos(Y2)*cos(Y2)+2.0*cos(Y1)*cos(Y2)*cos(X1-X2);
    YYC=atan2(sqrt(YYC),(sin(Y1)+sin(Y2)));
    YYC=90.0 - YYC/DEG2RAD;
%    return
end % SUBROUTINE ARCC_DBL
