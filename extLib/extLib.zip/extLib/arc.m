function[ARCL ] = arc(XX1,YY1,XX2,YY2)
% call from  cells_area ; mod_spherical.F 
% (c) dmitry.aleynik@sams.ac.uk 2018.09.13;                               & 
%  __o_O__�                                                               &
%  \_____/ ~~~~~~<@})))< ~ ~ ~~~~~ ~~~ SAMS KTP                           &
%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
%  SUBROUTINE ARC_DBL(XX1,YY1,XX2,YY2,ARCL)
  DEG2RAD=pi/180;  %  DEG2RAD=3.14159265/180;
  REARTH= 6371.0*1000; %m
%  TPI       = DEG2RAD*REARTH ; %!TPI=pi*rearth/180.=3.14159265/180.0*6371.*1000.
 
    X1=XX1*DEG2RAD;
    Y1=YY1*DEG2RAD;

    X2=XX2*DEG2RAD;
    Y2=YY2*DEG2RAD;

    XA=cos(Y1)*cos(X1);
    YA=cos(Y1)*sin(X1);
    ZA=sin(Y1);

    XB=cos(Y2)*cos(X2);
    YB=cos(Y2)*sin(X2);
    ZB=sin(Y2);

    AB=sqrt((XB-XA)^2+(YB-YA)^2+(ZB-ZA)^2);
    AOB=(2.0 -AB*AB)/2.0;
    AOB=acos(AOB);
    ARCL=REARTH*AOB;
    
%    return
end % SUBROUTINE ARCC_DBL
