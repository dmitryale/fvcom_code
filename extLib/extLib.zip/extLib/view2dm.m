%VIEW2DM plots the SMS 2dm Meshfile using MATLAB's "patch" function.
%
%   [fac vert] = view2dm(fileName,cmap,sh,li) imports the SMS 2dm Mesh file, parses it based
%   on triangular or quadrilateral elements, plots it using 'patch', and allows the user
%   to specify the colormap, shading, and lighting. The faces and vertices
%   of each element (or 'patch') are returned to the MATLAB workspace.
%
%   fileName is the file path of the 2dm file.
%
%   cmap is a string defining the type of colormap used by MATLAB's 'colormap' function.
%   'jet','copper','hsv', and 'bone' are just a few of the available, see
%   MATLAB Help for more information.
%
%   sh is a string setting the color shading properties. MATLAB allows for

%   'flat', 'faceted', and 'interp', where 'faceted' should be used when
%   the user wished to view the element edges of the Mesh.
%
%   li is a string specifying the lighting algorithm. MATLAB uses 'flat',
%   'gouraud', 'phong', and 'none'.
%
%   al sets the transparency of the Mesh were 0 is completely transparent,
%   and 1 is completely opaque.
%
%   fac returns the faces of each element, in the SMS 2dm Mesh these are
%   the same as the elements. NOTE: this function ONLY allows reads
%   triangular and quadrilateral elements! A single Mesh may however, contain both types.
%
%   vert returns the vertices of each element, in the SMS 2dm Mesh these are
%   the same as the nodes.
%
%
%   Example
%       View the SMS 2dm Mesh 'Example.2dm' with the 'jet' colormap,
%       showing the element edges using 'faceted' shading, and using the
%       'phong' lighting algorithm:
%       [vert fac] = view2dm('Example.2dm','jet','faceted','phong',1);
%
%
%   Copyright 2017 Jeffrey Andrew Tuhtan.
%   Contact: jtuhtan@gmail.com
%   $Last Revision 2017.04.24 $
%
function [vert fac] = view2dm(fileName,cmap,sh,li,al)
    %clear all
    %close all

    %% Use to test!
    % fileName = 'C:\Users\Tuhtan\Desktop\Hydro_as-2d.2dm';
    %%

    cmap = 'jet';
    sh = 'flat';
    li = 'phong';
    al = 1;

    NE = litcountquick(fileName,'E4Q'); % counts all rectangular elements
    NE2 = litcountquick(fileName,'E3T'); % counts all triangular elements
    NE = NE + NE2; % sums for the total number of elements
    ND = litcountquick(fileName,'ND'); % remove all data after the NS in the 2dm file!
    headerNum = NE+1;
    headerTot = NE*7;
    nodeNum = ND*5;
    headerTot = NE*7;

    fid = fopen(fileName);
    allText = textscan(fid,'%s'); %selects the element data, headerlines allows program to skip 1st row
    headerTest = strcmp(allText{1,1}(2),'MESHNAME');
    fclose(fid);

    if headerTest == 1;
        headerCount = 3;
        headerNum = headerNum+2;
    else
        headerCount = 1;
    end

    fid = fopen(fileName);
    elText = textscan(fid,'%s',headerTot,'headerlines',headerCount); %selects the element data, headerlines allows program to skip 1st row
    E4Q = elText{1,1};
    fclose(fid);

    fid = fopen(fileName);
    ndText = textscan(fid,'%s',nodeNum,'headerlines',headerNum); %selects the node data, headerlines allows program to skip down to ND dataset
    NData = ndText{1,1};
    fclose(fid);

    for i = 1:3
    NDxyz(i,:) = NData(i+2:5:end,1); % extract only the ND xyz values from the 2dm
    end

    for i = 1:6
    NEnum(i,:) = E4Q(i+1:7:end,1); % extract only the ND xyz values from the 2dm
    end

    %% Create output xyz dataset with the original NODE coordinates
    fid3 = fopen('NDxyz.dat','w','n');
    fprintf(fid3,'%s   %s   %s\n',NDxyz{:,1:ND});
    fclose(fid3);
    extracted_NDxyz = importdata('NDxyz.dat'); % import data as numeric

    plot3(extracted_NDxyz(:,1),extracted_NDxyz(:,2),extracted_NDxyz(:,3),'.')

    %% Select out the Material IDs for E4Q & E3T elements
    fid = fopen(fileName);
    textscan(fid,'%s','delimiter','','headerlines',headerCount); %selects the element data, headerlines allows program to skip 1st row
    E4Q = ans{1,1}; % creates a new data set consisting of entire row strings

    indexE4Q = strmatch('E4Q',E4Q); % indexes the quadrilateral elements
    indexE3T = strmatch('E3T',E4Q); % indexes the triangular elements
    extracted_E4Q = zeros(length(indexE4Q)+length(indexE3T),5); % preallocates the output material ID array based on its row location

    for i = 1:length(indexE4Q); % iterates over all of the QUADRILATERAL elements
    getstring = E4Q{indexE4Q(i),1}; % gets the whole row text string at each row based on the index
    erasetext = strrep(getstring,'E4Q',''); % removes the E4Q text from each selected string
    whitespaceremoval = strtrim(erasetext); % removes whitespaces at back and front of string
    [a b c d e f] = strread(whitespaceremoval); % creates a new dataset based on the 6 space delimited entries left
    extracted_E4Q(indexE4Q(i),1) = b;
    extracted_E4Q(indexE4Q(i),2) = c;
    extracted_E4Q(indexE4Q(i),3) = d;
    extracted_E4Q(indexE4Q(i),4) = e;
    extracted_E4Q(indexE4Q(i),5) = f; % selects the LAST entry of each, which is the material property!! :)
    end

    for i = 1:length(indexE3T); % iterates over all of the TRIANGULAR elements
    getstring = E4Q{indexE3T(i),1}; % gets the whole row text string at each row based on the index
    erasetext = strrep(getstring,'E3T',''); % removes the E3T text from each selected string
    whitespaceremoval = strtrim(erasetext); % removes whitespaces at back and front of string
    [a b c d e] = strread(whitespaceremoval); % creates a new dataset based on the 6 space delimited entries left
    extracted_E4Q(indexE3T(i),1) = b;
    extracted_E4Q(indexE3T(i),2) = c;
    extracted_E4Q(indexE3T(i),3) = d;
    extracted_E4Q(indexE3T(i),4) = d; % VERTEX DUPLICATED to keep matrix dimension constant!
    extracted_E4Q(indexE3T(i),5) = e; % selects the LAST entry of each, which is the material property!! :)
    end

    vert = extracted_NDxyz; % get the element vertices
    fac = extracted_E4Q(:,1:4); % get the element faces
    delete NDxyz.dat % deletes the temporary node information file NDxyz.dat

    %%  PLOT SUBSTRATE MAP
    figure();
    patch('Faces',fac,'Vertices',vert,'FaceVertexCData',extracted_E4Q(:,5),'FaceColor','interp') % plot the elements in MATLAB using patch
    title('Substrate Mapping');
    colormap(cmap);
    shading(sh);
    lighting(li);
    colorbar
    alpha(al);
    xlabel('X','FontSize',16); ylabel('Y','FontSize',16); zlabel('Elevation','FontSize',16);
    axis equal
    view(2);
    hold on
    %%

    %%  PLOT BED ELEVATION MAP
    figure();
    patch('Faces',fac,'Vertices',vert,'FaceVertexCData',vert(:,3),'FaceColor','interp'); % plot the elements in MATLAB using patch
    title('Bed Elevation [m]');
    colormap(cmap);
    shading(sh);
    lighting(li);
    colorbar
    alpha(al);
    xlabel('X','FontSize',16); ylabel('Y','FontSize',16); zlabel('Elevation','FontSize',16);
    axis equal
    view(2);
    hold on
    %%

    NodesE3T = extracted_E4Q(indexE3T,1:3); % selects set of only triangular node numbers
    MatE3T = extracted_E4Q(indexE3T,5); % selects material properties of triangular elements

    NodesE4Q = extracted_E4Q(indexE4Q,1:4); % selects set of only quadrilateral node numbers
    MatE4Q = extracted_E4Q(indexE4Q,5); % selects material properties of quadrilateral elements
end

