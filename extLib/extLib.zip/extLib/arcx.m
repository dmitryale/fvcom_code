function[ARCX1 ]= arcx(XX1,YY1,XX2,YY2)
% call from SHAPE_COEF_GCN
% (c) dmitry.aleynik@sams.ac.uk 2018.09.13;                               & 
%  __o_O__�                                                               &
%  \_____/ ~~~~~~<@})))< ~ ~ ~~~~~ ~~~ SAMS KTP                           &
%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
% SUBROUTINE ARCX_DBL(XX1,YY1,XX2,YY2,ARCX1)
 DEG2RAD=pi/180;  
 REARTH= 6371.0*1000; %m
%  TPI       = DEG2RAD*REARTH ; %!TPI=pi*rearth/180.=3.14159265/180.0*6371.*1000.

    if ( XX1 == XX2 )
       ARCX1=0.0;
    else
       X1=XX1*DEG2RAD;
       Y1=YY1*DEG2RAD;

       X2=XX2*DEG2RAD;
       Y2=YY2*DEG2RAD;

       XTMP  = X2-X1;
       if (XTMP >  pi), ... 
          XTMP = -2*pi + XTMP;
       elseif ( XTMP < -pi ), ...
          XTMP = 2*pi+XTMP;
       end
       TY=0.5*(Y2+Y1);
       ARCX1=REARTH*cos(TY)*XTMP; 
    end
%     return
end  